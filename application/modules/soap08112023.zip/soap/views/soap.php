<!DOCTYPE html>
<html lang="en">

<head>
<?php $this->theme->head('theme_default'); ?>
<?php require_once(APPPATH.'../assets/app_hn/soapfnc/mnu-cmp-css.php');?>
<title>SOAP <?php echo $id_reg_set; ?></title>
</head>


<body>
<?php $this->theme->wrapper_open('theme_default'); ?>
<div class="loader-bg">
<div class="loader-bar"></div>
</div>

<div id="pcoded" class="pcoded">
<div class="pcoded-overlay-box"></div>
<div class="pcoded-container navbar-wrapper">

<div class="pcoded-main-container">
<div class="pcoded-wrapper">

<div class="pcoded-content">

<div class="page-header card">
<div class="row align-items-end">
<div class="col-lg-8">
<div class="page-header-title">
<i class="feather icon-feather bg-c-blue"></i>
<div class="d-inline">
<h5>SOAP</h5>

<span>klik row nomor registrasi untuk melihat soap pasien</span>
</div>
</div>
</div>
<div class="col-lg-4">
<div class="page-header-breadcrumb">
<ul class=" breadcrumb breadcrumb-title">
<li class="breadcrumb-item">
<a href="<?php echo base_url('./'); ?>"><i class="feather icon-home"></i></a>
</li>
<li class="breadcrumb-item">
<a href="<?php echo base_url('soap/'); ?>">SOAP</a>
</li>
</ul>
</div>
</div>
</div>
</div>

<div class="pcoded-inner-content">
<div class="main-body">
<div class="page-wrapper">

<div class="page-body">
<!--tab-->
<div class="row">
<div class="col-sm-12">

<div class="card">
<div class="card-header">
<h5>SOAP</h5>
</div>
<div class="card-block tab-icon">
 
<div class="row">
<div class="col-lg-12 col-xl-12">

<ul class="nav nav-tabs md-tabs " role="tablist">
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#assawal" role="tab" id="assawalset"><i class="icofont icofont-home"></i>Assesment Awal</a>
<div class="slide"></div>
</li>
<li class="nav-item">
<a class="nav-link" data-toggle="tab" href="#cppt" role="tab" id="pasiencppt"><i class="icofont icofont-ui-user "></i>CPPT</a>
<div class="slide"></div>
</li>
<li class="nav-item">
<a class="nav-link " data-toggle="tab" href="#resumemedis" role="tab" id="resume_medis_id"><i class="icofont icofont-eye "></i>Resume Medis</a>
<div class="slide"></div>
</li>
<li class="nav-item">
<a class="nav-link " data-toggle="tab" href="#suratsakit" role="tab" id="surat_sakit"><i class="icofont icofont-envelope "></i>Surat Sakit</a>
<div class="slide"></div>
</li>
</ul>
    <input type="text" id="idregset" name="idregset" value="<?php echo $id_reg; ?>" readonly hidden> 
    <input type="text" id="id_pasien" name="id_pasien" value="<?php echo $id_pasien; ?>" readonly hidden>
<div class="tab-content card-block">
<div class="tab-pane" id="assawal" role="tabpanel">

<div class="card table-card">
<div class="card-header">
<h5>CPPT VIEWER</h5>
</div>
<div class="card-block">
<div id="box_cppt_viewer_aswal">
</div>
</div>
</div>

<div class="card table-card">
<div class="card-header">
<h5>CPPT</h5>
</div>
<div class="card-block">
<div class="container-fluid">
	<form id="frm_asm_ri_dokter" method="post" action="<?php echo base_url('soap/act_asm_ranap/'.$id_reg.'/'.$id_pasien); ?>">
  <input type="hidden" id="id_asmri" name="id_asmri" value="<?php echo $row['id_asmri']; ?>">
  <input type="hidden" id="sql_command" name="sql_command" value="<?php echo $sql_command; ?>">
  <input type="hidden" id="kategori" name="kategori" value="ASM">
  <input type="hidden" id="asal_masuk_set" value="<?php echo $row['asal_masuk']; ?>" />
  <input type="hidden" id="cara_masuk_set" value="<?php echo $row['cara_masuk']; ?>" />
  <div class="row pnl">
    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Tanggal Masuk :</label>
        </div>
        <div class="col-sm-9">
          <label class="control-label"><?php echo $data_pasien['regdate']; ?></label>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Asal Masuk :</label>
        </div>
        <div class="col-sm-3">
          <input type="radio" name="asal_masuk" value="IGD" /> IGD
        </div>
        <div class="col-sm-5">
          <input type="radio" name="asal_masuk" value="Rawat Jalan" /> RAWAT JALAN
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Pengkajian :</label>
        </div>
        <div class="col-sm-9">
          <input type="text" name="tgl_pengkajian" id="tgl_pengkajian" class="form-control tanggal" value="<?php echo $row['tgl_pengkajian']; ?>">
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Cara Masuk :</label>
        </div>
        <div class="col-sm-3">
          <input type="radio" name="cara_masuk" value="JALAN" /> JALAN
        </div>
        <div class="col-sm-3">
          <input type="radio" name="cara_masuk" value="KURSI RODA" /> KURSI RODA
        </div>
        <div class="col-sm-3">
          <input type="radio" name="cara_masuk" value="BRANKAR" /> BRANKAR
        </div>
      </div>
    </div>

  </div>


	<h3 class="pnl-head-3" style="margin-top:30px">SUBJECTIVE</h3>
  <div class="row pnl">

    <div class="col-md-6">
      <div class="form-group">
        <label class="control-label">Keluhan Utama :</label>
        <textarea class="form-control input-focus area-scroll" id="keluhan_utama" name="keluhan_utama" rows="5"
          placeholder="Keluhan Utama"><?php echo $row['keluhan_utama']; ?></textarea>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-group">
        <label class="control-label">Riwayat Penyakit Sekarang :</label>
        <textarea class="form-control input-focus area-scroll" id="riwayat_sakit_now" name="riwayat_sakit" rows="5" placeholder="Riwayat Penyakit Sekarang"><?php echo $row['riwayat_sakit']; ?></textarea>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-group">
        <label class="control-label">Riwayat Penyakit Dahulu :</label>
        <textarea class="form-control input-focus area-scroll" id="riwayat_sakit_old" name="riwayat_sakit_dulu" rows="5" placeholder="Riwayat Penyakit Dahulu"><?php echo $riwayat_pasien['penyakit_dahulu']; ?></textarea>
      </div>
    </div>

    <!--/span-->
    <div class="col-md-6">
      <div class="form-group">
        <label class="control-label">Riwayat Pengobatan/Operasi/Obstetri :</label>
        <textarea class="form-control input-focus area-scroll" id="riwayat_pengobatan"
          name="riwayat_pengobatan" rows="5" placeholder="Riwayat Pengobatan/Operasi/Obstetri"><?php echo $riwayat_pasien['pengobatan']; ?></textarea>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-group">
        <label class="control-label">Riwayat Penyakit Keluarga :</label>
        <textarea class="form-control input-focus area-scroll" id="riwayat_sakit_keluarga"
          name="riwayat_sakit_keluarga" rows="5" placeholder="Riwayat Penyakit Keluarga"><?php echo $riwayat_pasien['penyakit_keluarga']; ?></textarea>
      </div>
    </div>

    <div class="col-md-6">
      <div class="form-group">
        <label class="control-label">Riwayat Alergi :</label>
        <textarea class="form-control input-focus area-scroll" id="riwayat_alergi" name="riwayat_alergi"
          rows="5" placeholder="Riwayat Alergi"><?php echo $riwayat_pasien['alergi']; ?></textarea>
      </div>
    </div>

  </div>
  <br>

	<h3 class="pnl-head-3">OBJECTIVE</h3>
  <div class="row pnl pnl-obj">
    <div class="col-md-12">
      <div class="form-group">
      	<textarea class="form-control input-focus area-scroll" id="objective" name="objective" rows="5"
          placeholder="Objective"><?php echo $row['objective']; ?></textarea>
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
        <h4>TTV</h4>
        <hr>
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Kesadaran</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="kesadaran" name="kesadaran" placeholder="Kesadaran" value="<?php echo $row['kesadaran']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Keadaan Umum</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="keadaan_umum" name="keadaan_umum" placeholder="Keadaan Umum" value="<?php echo $row['keadaan_umum']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Tekanan Darah</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="td" name="td" placeholder="Tekanan Darah" value="<?php echo $row['td']; ?>">
      </div>
    </div>


    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">GCS</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="gcs" name="gcs" placeholder="GCS" value="<?php echo $row['gcs']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Nadi</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="nadi" name="nadi" placeholder="Nadi" value="<?php echo $row['nadi']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">SUHU</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="suhu" name="suhu" placeholder="SUHU" value="<?php echo $row['suhu']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Pernafasan</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="nafas" name="nafas" placeholder="Pernafasan" value="<?php echo $row['nafas']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Reaksi Cahaya</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="reaksi_cahaya" name="reaksi_cahaya" placeholder="Reaksi Cahaya" value="<?php echo $row['reaksi_cahaya']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Tinggi Badan</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="tinggi" name="tinggi" placeholder="Tinggi Badan" value="<?php echo $row['tinggi']; ?>">
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
        <label class="control-label">Berat Badan</label>
      </div>
    </div>

    <div class="col-md-4">
      <div class="form-group">
        <input type="text" class="form-control input-sm" id="berat" name="berat" placeholder="Berat Badan" value="<?php echo $row['berat']; ?>">
      </div>
    </div>



  </div>
  <br>

  <h3 class="pnl-head-3">ASSESMENT</h3>
  <div class="row pnl pnl-asm">
    <div class="col-md-12">
      <div class="form-group">
    		<h4>Diagnosa Medis dan Diagnosa Banding</h4>
        <hr>
      </div>
    </div>
    <?php
		for($i=0;$i<=4;$i++){
		$caption = ($i==0) ? "Utama" : ("Sekundari ".($i+0)) ;
		?>
    <div class="col-md-2">
      <div class="form-group">
      	<label class="control-label"><?php echo $caption; ?> :</label>
      </div>
    </div>
    <div class="col-md-8">
      <div class="form-group">
        <div class="ui-widget">
					<input id="name_icd_ten[<?php echo $i; ?>]" name="name_icd_ten[<?php echo $i; ?>]" class="form-control" value="<?php echo $arr_ten_text[$i]; ?>">
				</div>
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
        <input id="id_icd_ten[<?php echo $i; ?>]" name="id_icd_ten[<?php echo $i; ?>]" class="form-control" value="<?php echo $arr_ten[$i]; ?>">
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
				<input id="old_id_icd_ten[<?php echo $i; ?>]" name="old_id_icd_ten[<?php echo $i; ?>]" class="form-control" readonly>
      </div>
    </div>
		<?php
		}
		?>

  <div class="col-md-12" style="margin-top:30px">
    <div class="form-group">
      <h4>PEMERIKSAAN FISIK (GAMBAR)</h4>
      <hr>
    </div>
  </div>

  <div class="col-md-12">
    <div class="form-group">
      	<div id="box_drawing_canvas"></div>
    </div>
  </div>

  </div>

	<h3 class="pnl-head-3" style="margin-top:30px">PLANNING</h3>
  <div class="row pnl pnl-plan">
    <div class="col-md-12">
      <div class="form-group">
    		<h4>RENCANA TINDAKAN</h4>
        <hr>
      </div>
    </div>
    <?php
		for($i=0;$i<=2;$i++){
		$caption = ($i==0) ? "Utama" : ("Sekundari ".($i+0)) ;
		?>
    <div class="col-md-2">
      <div class="form-group">
      	<label class="control-label"><?php echo $caption; ?> :</label>
      </div>
    </div>
    <div class="col-md-8">
      <div class="form-group">
        <div class="ui-widget">
					<input id="name_icd_nine[<?php echo $i; ?>]" name="name_icd_nine[<?php echo $i; ?>]" class="form-control" value="<?php echo $arr_nine_text[$i]; ?>">
				</div>
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
        <input id="id_icd_nine[<?php echo $i; ?>]" name="id_icd_nine[<?php echo $i; ?>]" class="form-control" value="<?php echo $arr_nine[$i]; ?>">
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
				<input id="old_id_icd_nine[<?php echo $i; ?>]" name="old_id_icd_nine[<?php echo $i; ?>]" class="form-control" readonly>
      </div>
    </div>
		<?php
		}
		?>

    <div class="col-md-12" style="margin-top:30px">
      <div class="form-group">
        <h4>INSTRUKSI</h4>
        <hr>
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
      	<textarea class="form-control input-focus area-scroll" id="p_instruksi" name="p_instruksi" rows="5"
          placeholder="Instruksi"><?php echo $row['p_instruksi']; ?></textarea>
      </div>
    </div>

    <div class="col-md-12" style="margin-top:30px">
      <div class="form-group">
        <h4>RESEP ONLINE</h4>
        <hr>
      </div>
    </div>

    <div class="col-md-12">
    	<!--
      <div class="form-group">
        <label class="control-label"><strong>RESEP ONLINE</strong></label>
      </div>
			-->
      <div class="form-group" id="box_new_eresep">
        <div class="col-sm-12 text-center">
          <h5>Loading page content, please wait...</h5>
          <img src="<?php echo base_url('assets/img/loading-balls.gif'); ?>" alt="Loading Page">
        </div>
      </div>

    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_lab">
      <div class="form-group">
        <h4>LABORATORIUM</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_lab" style="background-color:white;">
    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_rad">
      <div class="form-group">
        <h4>RADIOLOGI</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_rad" style="background-color:white;">
    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_rehab">
      <div class="form-group">
        <h4>REHAB MEDIK</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_rehab" style="background-color:white;">
    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_op">
      <div class="form-group">
        <h4>OPERASI</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_op" style="background-color:white;">
    </div>

  </div>

  <div class="col-md-12 text-center" style="margin-top:30px;">
    	<button type="submit" class="btn btn-success" style="font-size:22px"> <i class="fa fa-check"></i> S I M P A N </button>
    </div>
	</form>
</div>
</div>
</div>
</div>
<div class="tab-pane" id="cppt" role="tabpanel">

<!--<div class="card table-card">
<div class="card-header">
<h5>LIST CPPT</h5>
</div>
<div class="card-block">
<div class="table-responsive">
<table class="table table-hover m-b-0">
<thead>
  <tr>
    <th scope="col">Noreg</th>
    <th scope="col">Tgl Kaji</th>
    <th scope="col">Kategori</th>
    <th scope="col">Jenis</th>
    <th scope="col">Edit</th>
    <th scope="col">Hapus</th>
  </tr>
</thead>
<tbody class="list_cppt_pasien"></tbody>
</table>
</div>
</div>
</div>-->

<div class="card table-card">
<div class="card-header">
<h5>CPPT VIEWER</h5>
</div>
<div class="card-block">
<div id="box_cppt_viewer">
</div>
</div>
</div>

<div class="card table-card">
<div class="card-header">
<h5>CPPT</h5>
</div>
<div class="card-block">
<form id="frm_cppt_ri_dokter" method="post" action="<?php echo base_url('soap/act_asm_ranap/'.$id_reg.'/'.$id_pasien); ?>">
  <input type="hidden" id="id_asmri" name="id_asmri">
  <input type="hidden" id="sql_command" name="sql_command">
  <input type="hidden" id="kategori" name="kategori" value="CPPT">
  <div class="row pnl">
    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Tanggal Masuk :</label>
        </div>
        <div class="col-sm-9">
          <label class="control-label">-</label>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Asal Masuk :</label>
        </div>
        <div class="col-sm-3">
          <input type="radio" name="asal_masuk" value="IGD" /> IGD
        </div>
        <div class="col-sm-5">
          <input type="radio" name="asal_masuk" value="Rawat Jalan" /> RAWAT JALAN
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Pengkajian :</label>
        </div>
        <div class="col-sm-9">
          <input type="text" name="tgl_pengkajian" id="tgl_pengkajian" class="form-control tanggalcppt">
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="row">
        <div class="col-sm-3">
          <label class="control-label">Cara Masuk :</label>
        </div>
        <div class="col-sm-3">
          <input type="radio" name="cara_masuk" value="JALAN" /> JALAN
        </div>
        <div class="col-sm-3">
          <input type="radio" name="cara_masuk" value="KURSI RODA" /> KURSI RODA
        </div>
        <div class="col-sm-3">
          <input type="radio" name="cara_masuk" value="BRANKAR" /> BRANKAR
        </div>
      </div>
    </div>

  </div>


	<h3 class="pnl-head-3" style="margin-top:30px">SUBJECTIVE</h3>
  <div class="row pnl">

    <div class="col-md-6">
      <div class="form-group">
        <label class="control-label">Keluhan Utama :</label>
        <textarea class="form-control input-focus area-scroll" id="keluhan_utama" name="keluhan_utama" rows="5"
          placeholder="Keluhan Utama"></textarea>
      </div>
    </div>

  </div>
  <br>

	<h3 class="pnl-head-3">OBJECTIVE</h3>
  <div class="row pnl pnl-obj">
  <!--
    <div class="col-md-12">
      <div class="form-group">
        <label class="control-label"><strong>OBJECTIVE</strong></label>
        <hr>
      </div>
    </div>
	-->

    <div class="col-md-12">
      <div class="form-group">
      	<textarea class="form-control input-focus area-scroll" id="objective" name="objective" rows="5"
          placeholder="Objective"></textarea>
      </div>
    </div>

  </div>
  <br>

  <h3 class="pnl-head-3">ASSESMENT</h3>
  <div class="row pnl pnl-asm">

    <div class="col-md-12">
      <div class="form-group">
    		<h4>Diagnosa Medis dan Diagnosa Banding</h4>
        <hr>
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
      	<label class="control-label">Utama :</label>
      </div>
    </div>
    <div class="col-md-8">
      <div class="form-group">
        <div class="ui-widget">
					<input id="name_icd_ten[0]" name="name_icd_ten[0]" class="form-control">
				</div>
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
        <input id="id_icd_ten[0]" name="id_icd_ten[0]" class="form-control">
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
				<input id="old_id_icd_ten[0]" name="old_id_icd_ten[0]" class="form-control" readonly>
      </div>
    </div>


  </div>

	<h3 class="pnl-head-3" style="margin-top:30px">PLANNING</h3>
  <div class="row pnl pnl-plan">
    <div class="col-md-12">
      <div class="form-group">
    		<h4>RENCANA TINDAKAN</h4>
        <hr>
      </div>
    </div>

    <div class="col-md-2">
      <div class="form-group">
      	<label class="control-label">Utama :</label>
      </div>
    </div>
    <div class="col-md-8">
      <div class="form-group">
        <div class="ui-widget">
					<input id="name_icd_nine[0]" name="name_icd_nine[0]" class="form-control">
				</div>
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
        <input id="id_icd_nine[0]" name="id_icd_nine[0]" class="form-control">
      </div>
    </div>
    <div class="col-md-1">
      <div class="form-group">
				<input id="old_id_icd_nine[0]" name="old_id_icd_nine[0]" class="form-control" readonly>
      </div>
    </div>

    <div class="col-md-12" style="margin-top:30px">
      <div class="form-group">
        <h4>INSTRUKSI</h4>
        <hr>
      </div>
    </div>

    <div class="col-md-12">
      <div class="form-group">
      	<textarea class="form-control input-focus area-scroll" id="p_instruksi" name="p_instruksi" rows="5"
          placeholder="Instruksi"></textarea>
      </div>
    </div>

    <div class="col-md-12" style="margin-top:30px">
      <div class="form-group">
        <h4>RESEP ONLINE</h4>
        <hr>
      </div>
    </div>

    <div class="col-md-12">
    	<!--
      <div class="form-group">
        <label class="control-label"><strong>RESEP ONLINE</strong></label>
      </div>
			-->
      <div class="form-group" id="box_new_eresep_add">
        <div class="col-sm-12 text-center">
          <h5>Loading page content, please wait...</h5>
          <img src="<?php echo base_url('assets/img/loading-balls.gif'); ?>" alt="Loading Page">
        </div>
      </div>

    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_lab">
      <div class="form-group">
        <h4>LABORATORIUM</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_lab" style="background-color:white;">
    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_rad">
      <div class="form-group">
        <h4>RADIOLOGI</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_rad" style="background-color:white;">
    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_rehab">
      <div class="form-group">
        <h4>REHAB MEDIK</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_rehab" style="background-color:white;">
    </div>

    <div class="col-md-12" style="margin-top:30px" id="anchor_order_op">
      <div class="form-group">
        <h4>OPERASI</h4>
        <hr>
      </div>
    </div>
    <div class="col-md-12" id="loader_box_op" style="background-color:white;">
    </div>


  </div>

  <div class="col-md-12 text-center" style="margin-top:30px;">
    	<button type="submit" class="btn btn-success" style="font-size:22px"> <i class="fa fa-check"></i> S I M P A N </button>
  </div>
	</form>
  </div>
  </div>
</div>
<div class="tab-pane" id="resumemedis" role="tabpanel">
<div id="box_resume_medis"></div>
</div>
<div class="tab-pane" id="suratsakit" role="tabpanel">
<div id="box_surat_sakit"></div>
</div>
</div>
</div>
</div>

</div>
</div>

</div>
</div>
<!--end tab-->
</div>

</div>
</div>
</div>
</div>


<div id="styleSelector">
</div>
</div>
</div>
</div>
</div>


<!--MODAL SEGMENT 3-->
<div class="modal fade" id="myModal3" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-lg" role="document" style="max-width:80%;">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">CPPT</h4>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<!--<h5>Default Modal</h5>-->
<div class="row">
<div class="col-sm-12">

<div class="card table-card">
<div class="card-header">
<h5 class="descdetailpaket"></h5>
<div class="card-header-right">
<ul class="list-unstyled card-option">
<li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
<li><i class="feather icon-maximize full-card"></i></li>
<li><i class="feather icon-minus minimize-card"></i></li>
<li><i class="feather icon-refresh-cw reload-card"></i></li>
<li><i class="feather icon-trash close-card"></i></li>
<li><i class="feather icon-chevron-left open-card-option"></i></li>
</ul>
</div>
</div>
<div class="card-block">
<form method="POST" action="<?php echo base_url('soap/proses_save'); ?>" id="transaksisetform">
    <div class="form-body" bis_skin_checked="1">
      <!-- Hidden fields -->
      <input type="hidden" class="form-control input-default" id="id_asmri" name="id_asmri">
      <input type="hidden" class="form-control input-default" id="id_reg" name="id_reg" value="<?php echo $id_reg_set; ?>">
      <!-- Hidden fields -->

      <h3 class="pnl-head-3">SUBJECTIVE</h3>
      <div class="row pnl" bis_skin_checked="1">
        <div class="col-md-6" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">Keluhan Utama :</label>
            <textarea class="form-control input-focus area-scroll" id="keluhan_utama_add" name="keluhan_utama_add" rows="5" placeholder="Keluhan Utama"></textarea>
          </div>

          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">Riwayat Penyakit Sekarang :</label>
            <textarea class="form-control input-focus area-scroll" id="riwayat_sakit_add" name="riwayat_sakit_add" rows="5" placeholder="Riwayat Penyakit Sekarang"></textarea>
          </div>

          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">Riwayat Penyakit Dahulu :</label>
            <textarea class="form-control input-focus area-scroll" id="riwayat_sakit_dulu_add" name="riwayat_sakit_dulu_add" rows="5" placeholder="Riwayat Penyakit Dahulu"></textarea>
            <hr>
          </div>
        </div>
        <!--/span-->
        <div class="col-md-6" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">Riwayat Pengobatan/Operasi/Obstetri :</label>
            <textarea class="form-control input-focus area-scroll" id="riwayat_pengobatan_add" name="riwayat_pengobatan_add" rows="5" placeholder="Riwayat Pengobatan/Operasi/Obstetri"></textarea>
          </div>

          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">Riwayat Penyakit Keluarga :</label>
            <textarea class="form-control input-focus area-scroll" id="riwayat_sakit_keluarga_add" name="riwayat_sakit_keluarga_add" rows="5" placeholder="Riwayat Penyakit Keluarga"></textarea>

          </div>

          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">Riwayat Alergi :</label>
            <textarea class="form-control input-focus area-scroll" id="riwayat_alergi_add" name="riwayat_alergi_add" rows="5" placeholder="Riwayat Alergi"></textarea>
            <hr>
          </div>
        </div>

      </div>

      <h3 class="pnl-head-3">OBJECTIVE</h3>
      <div class="row pnl" bis_skin_checked="1">

        <div class="col-md-12" bis_skin_checked="1">
          <!-- START PEMERIKSAAN UMUM -->
          <label class="control-label"><strong>PEMERIKSAAN KONDISI UMUM DAN TANDA TANDA VITAL</strong></label>

          <div class="row" bis_skin_checked="1">
            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Kesadaran</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="kesadaran_add" name="kesadaran_add" placeholder="Kesadaran">
              </div>
            </div>

            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Keadaan Umum</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="keadaan_umum_add" name="keadaan_umum_add" placeholder="Keadaan Umum">
              </div>
            </div>


            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Tekanan Darah</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="td_add" name="td_add" placeholder="Tekanan Darah">
              </div>
            </div>


            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">GCS</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="gcs_add" name="gcs_add" placeholder="GCS">
              </div>
            </div>

            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Nadi</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="nadi_add" name="nadi_add" placeholder="Nadi">
              </div>
            </div>

            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">SUHU</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="suhu_add" name="suhu_add" placeholder="SUHU">
              </div>
            </div>

            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Pernafasan</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="nafas_add" name="nafas_add" placeholder="Pernafasan">
              </div>
            </div>

            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Reaksi Cahaya</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="reaksi_cahaya_add" name="reaksi_cahaya_add" placeholder="Reaksi Cahaya">
              </div>
            </div>

            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Tinggi Badan</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="tinggi_add" name="tinggi_add" placeholder="Tinggi Badan">
              </div>
            </div>

            <div class="col-md-2" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Berat Badan</label>
              </div>
            </div>

            <div class="col-md-4" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <input type="text" class="form-control input-sm" id="berat_add" name="berat_add" placeholder="Berat Badan">
              </div>
            </div>
          </div>

        </div><!-- END PEMERIKSAAN UMUM -->

        <div class="col-md-12" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label"><strong>Pemeriksaan Fisik Khusus</strong></label>
            <textarea class="form-control input-focus area-scroll" id="fisik_khusus_add" name="fisik_khusus_add" rows="5" placeholder="Pemeriksaan Fisik Khusus"></textarea>
          </div>
        </div>

        <div class="col-md-12" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label"><strong>PEMERIKSAAN UMUM</strong></label>
          </div>

          <div class="row" bis_skin_checked="1">

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">KEPALA :</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpukepala_add" id="selmstpukepala_add" name="selmstpukepala_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">RAMBUT:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpurambut_add" id="selmstpurambut_add" name="selmstpurambut_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">WAJAH:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpuwajah_add" id="selmstpuwajah_add" name="selmstpuwajah_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">MATA:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpumata_add" id="selmstpumata_add" name="selmstpumata_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">GIGI:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpugigi_add" id="selmstpugigi_add" name="selmstpugigi_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Tenggorokan:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstputenggorokan_add" id="selmstputenggorokan_add" name="selmstputenggorokan_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">LIDAH:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpulidah_add" id="selmstpulidah_add" name="selmstpulidah_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">LEHER:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpuleher_add" id="selmstpuleher_add" name="selmstpuleher_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">ABDOMEN:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpuabdomen_add" id="selmstpuabdomen_add" name="selmstpuabdomen_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">DADA:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpudada_add" id="selmstpudada_add" name="selmstpudada_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">RESPIRASI:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpurespirasi_add" id="selmstpurespirasi_add" name="selmstpurespirasi_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">JANTUNG:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpujantung_add" id="selmstpujantung_add" name="selmstpujantung_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Integumen:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpuintegumen_add" id="selmstpuintegumen_add" name="selmstpuintegumen_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Ekstremitas:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpuekstremitas_add" id="selmstpuekstremitas_add" name="selmstpuekstremitas_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Genetalia:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpugenetalia_add" id="selmstpugenetalia_add" name="selmstpugenetalia_add"></select>
              </div>
            </div>

            <div class="col-md-1" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <label class="control-label">Eliminiasi:</label>
              </div>
            </div>

            <div class="col-md-5" bis_skin_checked="1">
              <div class="form-group" bis_skin_checked="1">
                <select class="js-example-basic-single col-sm-12 selmstpuelimitas_add" id="selmstpuelimitas_add" name="selmstpuelimitas_add"></select>
              </div>
            </div>

          </div>
        </div>



        <div class="col-md-6" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">PEMERIKSAAN PENUNJANG :</label>
            <textarea class="form-control input-focus area-scroll" id="pemeriksaan_penunjang_add" name="pemeriksaan_penunjang_add" rows="5" placeholder="Pemeriksaan Penunjang"></textarea>
          </div>
        </div>

        <div class="col-md-6" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">MASALAH KESEHATAN :</label>
            <textarea class="form-control input-focus area-scroll" id="masalah_kesehatan_add" name="masalah_kesehatan_add" rows="5" placeholder="MASALAH KESEHATAN"></textarea>
          </div>
        </div>

      </div>

      <h3 class="pnl-head-3">ASSESMENT</h3>
      <div class="row pnl" bis_skin_checked="1">
        <div class="col-md-12" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label">MASALAH KEPERAWATAN :</label>
            <textarea class="form-control input-focus area-scroll" id="masalah_keperawatan_add" name="masalah_keperawatan_add" rows="8" placeholder="MASALAH KEPERAWATAN"></textarea>
          </div>
        </div>

      </div>

      <h3 class="pnl-head-3">PLANNING</h3>
      <div class="row pnl" bis_skin_checked="1">

        <div class="col-md-12" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label"><strong>RENCANA KEPERAWATAN/TARGET TERUKUR</strong></label>
            <textarea class="form-control input-focus area-scroll" id="rencana_keperawatan_add" name="rencana_keperawatan_add" rows="5" placeholder="RENCANA KEPERAWATAN/TARGET TERUKUR"></textarea>
          </div>
        </div>

        <div class="col-md-12" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label"><strong>KEBUTUHAN EDUKASI / PENDIDIKAN KESEHATAN :</strong></label>
            <div class="row" bis_skin_checked="1">
              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Proses Penyakit"> Proses Penyakit
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Pengobatan/tindakan" checked="checked"> Pengobatan/tindakan
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Tata tertib Rumah sakit"> Tata tertib Rumah sakit
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Nutrisi/diet"> Nutrisi/diet
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Perawatan perioperative"> Perawatan perioperative
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Manajemen nyeri"> Manajemen nyeri
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Pelayanan spiritual"> Pelayanan spiritual
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Motivasi kesembuhan"> Motivasi kesembuhan
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Pelayanan islami"> Pelayanan islami
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Fasilitas ruangan"> Fasilitas ruangan
                </div>
              </div>

              <div class="col-md-2" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="edukasi[]" value="Informasi tentang tim medis"> Informasi tentang tim medis
                </div>
              </div>


            </div>
          </div>
        </div>

        <div class="col-md-12" bis_skin_checked="1">
          <div class="form-group" bis_skin_checked="1">
            <label class="control-label"><strong>PERENCANAAN PASIEN PULANG :</strong></label>
            <div class="row" bis_skin_checked="1">
              <div class="col-md-4" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="pasien_pulang[]" value=" Diperlukan discharge planning">  Diperlukan discharge planning
                </div>
              </div>

              <div class="col-md-4" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="pasien_pulang[]" value="Usia > 65 tahun"> Usia &gt; 65 tahun
                </div>
              </div>

              <div class="col-md-4" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="pasien_pulang[]" value="Bantuan untuk melakukan aktifitas sehari-hari"> Bantuan untuk melakukan aktifitas sehari-hari
                </div>
              </div>

              <div class="col-md-4" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="pasien_pulang[]" value="Keterbatasan mobilitas"> Keterbatasan mobilitas
                </div>
              </div>

              <div class="col-md-4" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="pasien_pulang[]" value="Perawatan/pengobatan lanjutan"> Perawatan/pengobatan lanjutan
                </div>
              </div>

              <div class="col-md-4" bis_skin_checked="1">
                <div class="form-group" bis_skin_checked="1">
                  <input type="checkbox" name="pasien_pulang[]" value="Tidak Memerlukan discharge planning" checked="checked"> Tidak Memerlukan discharge planning
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>

        <div class="modal-footer" bis_skin_checked="1">
          <div class="form-actions" bis_skin_checked="1">
            <button type="submit" class="btn btn-success"><i class="fa fa-check"></i> Save</button>
            <button type="button" class="btn btn-inverse" data-dismiss="modal">Cancel</button>
          </div>
        </div>

    </div>
  </form>
</div>
</div>
</div>


</div>
</div>
</div>

</div>
</div>
</div>
<!--END MODAL SEGMENT 3-->


<!--MODAL SEGMENT 4-->
<div class="modal fade" id="myModal4" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-lg" role="document" style="max-width:80%;">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">CPPT</h4>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<!--<h5>Default Modal</h5>-->
<div class="row">
<div class="col-sm-12">

<div class="card table-card">
<div class="card-header">
<h5 class="descdetailpaket"></h5>
<div class="card-header-right">
<ul class="list-unstyled card-option">
<li class="first-opt"><i class="feather icon-chevron-left open-card-option"></i></li>
<li><i class="feather icon-maximize full-card"></i></li>
<li><i class="feather icon-minus minimize-card"></i></li>
<li><i class="feather icon-refresh-cw reload-card"></i></li>
<li><i class="feather icon-trash close-card"></i></li>
<li><i class="feather icon-chevron-left open-card-option"></i></li>
</ul>
</div>
</div>
<div class="card-block">
------------------------
</div>
</div>
</div>


</div>
</div>
</div>

</div>
</div>
</div>
<!--END MODAL SEGMENT 4-->

<!--MODAL SEGMENT 5-->
<div class="modal fade" id="myModal5" tabindex="-1" role="dialog" data-backdrop="static" data-keyboard="false">
<div class="modal-dialog modal-lg" role="document" style="max-width:80%;">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">EDIT CPPT</h4>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<!--<h5>Default Modal</h5>-->
<div class="row">
<div class="col-sm-12">

<div class="card table-card">
<div class="card-block">
<div id="box_list_cppt"></div>
</div>
</div>
</div>


</div>
</div>
</div>

</div>
</div>
<!--END MODAL SEGMENT 5-->
</body>
<?php  ?>


<?php $this->theme->wrapper_close('theme_default'); ?>
<?php $this->theme->script('theme_default'); ?>
<?php require_once(APPPATH.'../assets/app_hn/soapfnc/mnu-cmp-js.php');?>
<script src=<?php echo base_url('assets/app_hn/soapfnc/fncsoap.js'); ?>></script>