<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Eresep extends MX_Controller
{
	var $session_name='sp';
    function __construct()
    {
        parent::__construct();
				#modules::run('auth/check_session');
        $this->load->model('Eresep_model');
				$this->load->library('SmartLib');
				$this->load->library('Antrolib');

				date_default_timezone_set('Asia/Jakarta');
    }
//////////////////////////////////////
public function save_eresep_nonracikan()
{
	$username = $this->session->userdata['sp']->login_name;
    
    ## --- data header ---
    $id_eresep = $this->input->post('ideresep');
    $id_reg = $this->input->post('id_reg');
    $id_pasien = $this->input->post('id_pasien');
    $now = date('Y-m-d H:i:s');

    ## --- data detail ---
    $obat 			        = $this->input->post('obat');
    $id_fa 			        = $this->input->post('id_fa');
    $jenis_obat             = $this->input->post('jenis_obat');
    $qty 			        = $this->input->post('qty');
    $dosis 			        = $this->input->post('dosis');
    $frekwensi 	            = $this->input->post('frekwensi');
    $tme 			        = $this->input->post('tme');
    $harga 			        = $this->input->post('harga');
    $total_harga_obat 	    = $this->input->post('total_harga_obat');
    $note 			        = $this->input->post('note');

    ### --- INSERT eresep detail ----------------------------------
    if(isset($obat))
    {

            $sql_insert_det = "INSERT INTO `soap_eresep_det` (`id_eresep`, `id_trx_det`, `name`, `jenis_obat`, `qty`, `dosis`, `tme`, `frekwensi`, `harga_satuan`, `subtotal` ,`note`,`created`,`created_by`)
            VALUES 	
            ('".$id_eresep."', '".$id_fa."', '".$obat."', '".$jenis_obat."', '".$qty."', '".$dosis."', '".$tme."', '".$frekwensi."', '".$harga."', '".$total_harga_obat."', '".$note."','".$now."','".$username."')";
            $ok_inv = $this->dbhis->query($sql_insert_det);

    }
   $fbck = "ok";
   $dataset = json_encode($fbck);
   echo $dataset;
}

public function save_eresep_racikan()
{
	$id_eresep = $this->input->post('ideresep_rck');
	## --- data header ---
	$id_reg = $this->input->post('id_reg_rck',true);
	$id_pasien = $this->input->post('id_pasien',true);
	$now = date('Y-m-d H:i:s');



	## ---  data racikan ; headernya ------------------
	$nama_racikan 			= $this->input->post('nama_racikan',true);
	$harga 			= $this->input->post('harga',true);
	$subtotal 			= $this->input->post('subtotal',true);
	$jumlah_racikan 	= $this->input->post('jumlah_racikan',true);
	$dosis_racikan 	= $this->input->post('dosis_racikan',true);
	$frekwensi_racikan 	= $this->input->post('frekwensi_racikan',true);
	$tme_racikan 				= $this->input->post('tme_racikan',true);
	$kemasan_racikan 		= $this->input->post('kemasan_racikan',true);
	$note_racikan 			= $this->input->post('note_racikan',true);
	## contoh format : nama_racikan[0]

	## ---  data racikan detail ; detailnya ------------------
	$det_racikan_obat 	= $this->input->post('det_racikan_obat',true);
	$det_id_fa 		= $this->input->post('det_id_fa',true);
	$det_jenis_obat 		= $this->input->post('det_jenis_obat',true);
	$det_racikan_qty 		= $this->input->post('det_racikan_qty',true); 
	$det_racikan_harga 		= $this->input->post('det_racikan_harga',true);
	$det_racikan_subtotal 		= $this->input->post('det_racikan_subtotal',true);
	#$det_racikan_dosis 	= $this->input->post('det_racikan_dosis',true);


	$id_dokter_penginput = $this->session->userdata['sp']->id_dokter;
	### --- INSERT eresep ---------------------------------
	$sql_insert_header = "	INSERT INTO `soap_eresep`
																(`eresepdate`, `id_reg`, `is_eresep_pulang`,`id_dokter`)
													VALUES
																('".$now."', '".$id_reg."', '".$is_eresep_pulang."','".$id_dokter_penginput."')";
	$ok = $this->dbhis->query($sql_insert_header);


	if(isset($nama_racikan))
	{
		foreach($nama_racikan as $k => $v)
		{
			#### dibawah ini masukin header racikan di detail resep ---------
			$sql_insert_det = "INSERT INTO `soap_eresep_det`
															(`id_eresep`			, `id_trx_det`	, `name`		, `jenis_obat`								, `qty`													, `dosis`										, `tme`										, `frekwensi`										, `note`									, `is_racikan`)
											VALUES 	('".$id_eresep."'	, 0							, '".$v."'	, '".$kemasan_racikan[$k]."'	, '".$jumlah_racikan[$k]."'			, '".$dosis_racikan[$k]."'	, '".$tme_racikan[$k]."'	, '".$frekwensi_racikan[$k]."'	, '".$note_racikan[$k]."'	, 1)";
			$ok = $this->dbhis->query($sql_insert_det);

			### --- GET id_eresep ---------------------------------
			$sql 						= "SELECT LAST_INSERT_ID() as id_eresep_det";
			$query 					= $this->dbhis->query($sql);
			$rs 						= $query->row_array();
			$id_eresep_det 	= $rs['id_eresep_det'];
			foreach($det_racikan_obat[$k] as $kk => $vv)
			{

				$sql_insert_det_racikan = "INSERT INTO `soap_eresep_det_racikan` (
																		`id_eresep_det`			,`id_eresep`			,`id_trx_det`							,`name`			,`jenis_obat`										,`qty`,`harga_satuan`,`subtotal`)
													VALUES 	(	'".$id_eresep_det."','".$id_eresep."'	,'".$det_id_fa[$k][$kk]."','".$vv."'	,'".$det_jenis_obat[$k][$kk]."'	,'".$det_racikan_qty[$k][$kk]."','".$det_racikan_harga[$k][$kk]."','".$det_racikan_subtotal[$k][$kk]."')
				";
				$ok = $this->dbhis->query($sql_insert_det_racikan);
			}
		}
	}

	$fcbk = "ok";
	$dataset = json_encode($fcbk);
	echo $dataset;
}

function mst_setting_harga(){
    $datasett   	= $this->Eresep_model->mst_setting_harga();
    $dataset 		= json_encode($datasett);
    echo $dataset;
}


function prosesdetailobat(){
    $id_obat    = $this->input->post('id_obat');
    $datasett   = $this->Eresep_model->detail_obatnya($id_obat);
    $row_1      = $datasett->harga_margin;

    $data = array(
        'row_1'     => $row_1
    );

    $dataset = json_encode($data);
    echo $dataset; 
}    

function detailobatnonracikan(){
    $id_eresep    	= $this->input->post('id_eresep');
    $datasett   	= $this->Eresep_model->detail_obat_eresep_nonracik($id_eresep);
    $dataset 		= json_encode($datasett);
    echo $dataset;
}



function list_detailobatnonracikan(){
    $id_eresep    	= $this->input->post('id_eresep');
    $datasett   	= $this->Eresep_model->list_detail_obat_eresep_nonracik($id_eresep);
    $dataset 		= json_encode($datasett);
    echo $dataset;
}


function deleteobatnya(){
    $id_eresep    	= $this->input->post('id_eresep_det');
    $datasett   	= $this->Eresep_model->delete_obatnya($id_eresep);
    $dataset 		= json_encode($datasett);
    echo $dataset;
}

function validasiobatnya(){
    $id_eresep    	= $this->input->post('id_eresep_det');
	//setting nya
	$setting_harga = $this->Eresep_model->mst_setting_harga();
	$tuslah        = $setting_harga->tuslah;
	//end setting nya

	//search data harga obat
	$dataobatset = $this->Eresep_model->data_obat_search($id_eresep);
	$subtotal        = $dataobatset->subtotal;
	//end search data harga obat

	$subtotal_new = ($subtotal + $tuslah);
	
	$datasett   	= $this->Eresep_model->validasi_obatnya($id_eresep,$subtotal_new);
    $dataset 		= json_encode($datasett);
    echo $dataset;
}

function cancelobatnya(){
    $id_eresep    	= $this->input->post('id_eresep_det');

	//setting nya
	$setting_harga = $this->Eresep_model->mst_setting_harga();
	$tuslah        = $setting_harga->tuslah;
	//end setting nya

	//search data harga obat
	$dataobatset = $this->Eresep_model->data_obat_search($id_eresep);
	$subtotal        = $dataobatset->subtotal;
	//end search data harga obat

	$subtotal_new = ($subtotal - $tuslah);

    $datasett   	= $this->Eresep_model->cancel_obatnya($id_eresep,$subtotal_new);
    $dataset 		= json_encode($datasett);
    echo $dataset;
}


public function detailobatracikan(){
    $id_eresep    	= $this->input->post('id_eresep');
    $sql_1="SELECT 	a.*,b.*
	FROM 		soap_eresep a, soap_eresep_det b
	WHERE 	a.id_eresep=b.id_eresep
					AND a.id_eresep='".$id_eresep."'
					AND b.is_racikan=1
					AND b.status=0
					AND b.is_validasi=0
	ORDER BY a.id_eresep DESC";
    $query_1 = $this->db->query($sql_1);
    $rs_1 = $query_1->result_array();
  
    foreach($rs_1 as $k1 => $v_1){
  
    $id_eresep_det  = $v_1['id_eresep_det'];
        
    $sql_2 = "SELECT 	b.*
	FROM 		soap_eresep_det a, soap_eresep_det_racikan b
	WHERE 	a.id_eresep_det=b.id_eresep_det
					AND a.id_eresep_det='".$id_eresep_det."'";
    //echo "<pre>".$sql_2;
    $query_2 	= $this->db->query($sql_2);
    $rs2 	= $query_2->result_array();
    $rs_1[$k1]['rs_1'] = $rs2;
  
  
    }//end lvl 1
  
    echo json_encode($rs_1);
  
}

public function validasidetailobatracikan(){
    $id_eresep    	= $this->input->post('id_eresep');
    $sql_1="SELECT 	a.*,b.*
	FROM 		soap_eresep a, soap_eresep_det b
	WHERE 	a.id_eresep=b.id_eresep
					AND a.id_eresep='".$id_eresep."'
					AND b.is_racikan=1 AND b.status=0 AND b.is_validasi=1
	ORDER BY a.id_eresep DESC";
    $query_1 = $this->db->query($sql_1);
    $rs_1 = $query_1->result_array();
  
    foreach($rs_1 as $k1 => $v_1){
  
    $id_eresep_det  = $v_1['id_eresep_det'];
        
    $sql_2 = "SELECT 	b.*
	FROM 		soap_eresep_det a, soap_eresep_det_racikan b
	WHERE 	a.id_eresep_det=b.id_eresep_det
					AND a.id_eresep_det='".$id_eresep_det."'";
    //echo "<pre>".$sql_2;
    $query_2 	= $this->db->query($sql_2);
    $rs2 	= $query_2->result_array();
    $rs_1[$k1]['rs_1'] = $rs2;
  
  
    }//end lvl 1
  
    echo json_encode($rs_1);
  
}

function hapusobatnya_rck(){
    $id_eresep    	= $this->input->post('id_eresep_det');
    $datasett   	= $this->Eresep_model->hapus_obatnya_rck($id_eresep);
    $dataset 		= json_encode($datasett);
    echo $dataset;
}

function validasiobatnya_rck(){
    $id_eresep    	= $this->input->post('id_eresep_det');
	//setting nya
	$setting_harga = $this->Eresep_model->mst_setting_harga();
	$tuslah        = $setting_harga->tuslah;
	$racik		   = $setting_harga->jasa_racik;
	//end setting nya

	//search data harga obat
	$dataobatset = $this->Eresep_model->data_obat_search_rck($id_eresep);
	foreach($dataobatset as $dataracik){
		$id_item_racikan    = $dataracik['id_eresep_det_racikan'];
		$subtotal        	= $dataracik['subtotal'];
		$subtotal_new 		= ($subtotal + $tuslah);
		$datasett2   		= $this->Eresep_model->validasi_obatnya_hrg_rck($id_item_racikan,$subtotal_new);
	}
	$qtytotal   			= $this->Eresep_model->qty_obatnya_hrg_rck($id_eresep);
	$qty_set				= $qtytotal->qty;
	$sumtotal   			= $this->Eresep_model->sum_obatnya_hrg_rck($id_eresep);
	$grandtotal_sat_set		= $sumtotal->grandtotal;
	$cal_sub_racikan		= ($qty_set * $grandtotal_sat_set)+$racik;
	$update_to_subtotal     = $this->Eresep_model->update_obatnya_hrg_rck($id_eresep,$grandtotal_sat_set,$cal_sub_racikan);
	//end search data harga obat

	$data_view = array(
		'id_item_racikan'	=> $id_item_racikan,
		'subtotal'			=> $subtotal,
		'subtotal_new'		=> $subtotal_new
	);


    $datasett   	= $this->Eresep_model->validasi_obatnya_rck($id_eresep);
    $dataset 		= json_encode($data_view);
    echo $dataset;
}

function cancelobatnya_rck(){
    $id_eresep    	= $this->input->post('id_eresep_det');
	//setting nya
	$setting_harga = $this->Eresep_model->mst_setting_harga();
	$tuslah        = $setting_harga->tuslah;
	$racik		   = $setting_harga->jasa_racik;
	//end setting nya

	//search data harga obat
	$dataobatset = $this->Eresep_model->data_obat_search_rck($id_eresep);
	foreach($dataobatset as $dataracik){
		$id_item_racikan    = $dataracik['id_eresep_det_racikan'];
		$subtotal        	= $dataracik['subtotal'];
		$subtotal_new 		= ($subtotal - $tuslah);
		$datasett2   		= $this->Eresep_model->cancel_obatnya_hrg_rck($id_item_racikan,$subtotal_new);
	}
	$grandtotal_sat_set		= 0;
	$cal_sub_racikan		= 0;
	$update_to_subtotal     = $this->Eresep_model->update_obatnya_hrg_rck($id_eresep,$grandtotal_sat_set,$cal_sub_racikan);
	//end search data harga obat

	$data_view = array(
		'id_item_racikan'	=> $id_item_racikan,
		'subtotal'			=> $subtotal,
		'subtotal_new'		=> $subtotal_new
	);

    $datasett   	= $this->Eresep_model->cancel_obatnya_rck($id_eresep);
    $dataset 		= json_encode($data_view);
    echo $dataset;
}

function edit_nonracikan(){
    $id_eresep    	= $this->input->post('id');
	$qty	    	= $this->input->post('qty_edit_set');
	$dat_obat   	= $this->Eresep_model->data_search_obat($id_eresep);
	$harga_satuan_set   = $dat_obat->harga_satuan;
	$harga_subtotal_set = ($harga_satuan_set * $qty);
    $datasett   	= $this->Eresep_model->edit_nonracikan($id_eresep,$qty,$harga_subtotal_set);
	$fbck			= "ok";
    $dataset 		= json_encode($fbck);
    echo $dataset;
}

function edit_racikan(){
    $id_eresep    	= $this->input->post('id');
	$qty	    	= $this->input->post('qty_edit_set');
	$dat_obat   	= $this->Eresep_model->data_search_obat_racikan($id_eresep);
	$harga_satuan_set   = $dat_obat->harga_satuan;
	$harga_subtotal_set = ($harga_satuan_set * $qty);
    $datasett   	= $this->Eresep_model->edit_racikan($id_eresep,$qty,$harga_subtotal_set);
	$fbck			= "ok";
    $dataset 		= json_encode($fbck);
    echo $dataset;
}

//////////////////////////////////////
	public function riwayat_resep($id_reg,$is_html=false)
	{
		$pasien = $this->smartlib->get_data_pasien_by_id_reg($id_reg);
		$sql = "SELECT 	a.*,c.name AS nama_dokter, a.resepdate
						FROM 		trx_frm_resep a
										LEFT JOIN mst_dokter c ON (c.`id_dokter`=a.`id_dokter`)
										,trx_reg b
						WHERE		a.id_reg=b.id_reg
										AND b.id_pasien='".$pasien['id_pasien']."'
										AND a.cancel=0
						ORDER BY a.resepdate DESC
						LIMIT 10
						";
		#echo "<pre>".$sql."</pre>";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		foreach($rs as $k => $v)
		{
			switch($v['id_type'])
			{
				case '1':
					$tipe_rawat = 'R.Jalan';
					break;
				case '2':
					$tipe_rawat = 'R.Jalan';
					break;
				case '3':
					$tipe_rawat = 'R.Jalan';
					break;
				default:
					$tipe_rawat = 'R.Jalan';
					break;
			}
			$rs[$k]['tipe_rawat'] = $tipe_rawat;
		}
		$data = array(
			'rs' 						=> $rs,
			'id_reg'				=> $id_reg
		);
		echo $this->load->view('riwayat_resep', $data, $is_html=true);
	}

	public function list_resep_baru_input($id_reg,$is_html=false)
	{
		$sql = "SELECT 	a.*,b.*
						FROM 		soap_eresep a, soap_eresep_det b
						WHERE 	a.id_eresep=b.id_eresep
										AND a.id_reg='".$id_reg."'
						";
		$query = $this->dbhis->query($sql);
		$rs_eresep_det = $query->result_array();
		$data = array(
			'rs_eresep_det'	=> $rs_eresep_det,
			'id_reg'				=> $id_reg
		);
		return $this->load->view('list_resep_baru_input', $data,$is_html);
	}

	public function list_riwayat_resep_online($id_reg,$is_html=false,$id_pasien)
	{
		/*
		$sql = "SELECT 	a.*,b.*
						FROM 		soap_eresep a, trx_reg b
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien='".$id_pasien."'
						ORDER BY a.id_eresep DESC
						";
		*/
    //Query Asli PAk dadan
		/*
		$sql = "SELECT 	c.`id_dokter`,d.`name` AS nama_dokter,a.*,b.*
						FROM 		soap_eresep a, trx_reg b, mst_dokter d
										LEFT JOIN trx_reg_unit c ON (a.id_reg=c.id_reg AND c.`id_dokter`=d.`id_dokter`)
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien='".$id_pasien."'
						ORDER BY a.id_eresep DESC
						";
		*/
		/*
    $sql = "SELECT ax.`id_dokter`,ax.nama_dokter, ax.*, ax.id_eresep, ax.eresepdate, ax.is_printed
            FROM (
              SELECT 	c.`id_dokter`,d.`name` AS nama_dokter,e.name as nama_dokter_ri
              				,b.*, a.id_eresep, a.eresepdate, a.is_printed
              FROM 		soap_eresep a
              				LEFT JOIN trx_reg_unit c ON (a.id_reg=c.id_reg)
                      LEFT JOIN mst_dokter d ON (c.`id_dokter`=d.`id_dokter`)
                      ,trx_reg b
                      LEFT JOIN mst_dokter e ON (b.`id_dokter_prt1`=e.`id_dokter`)
              WHERE 	a.id_reg=b.id_reg
              				AND b.id_pasien='".$id_pasien."'
              UNION ALL
              SELECT 	d.id_dokter, d.`name` AS nama_dokter, NULL AS nama_dokter_ri
              				,b.*, a.id_eresep, a.eresepdate, a.is_printed
              FROM 		soap_eresep a, trx_reg b, mst_dokter d
              WHERE 	b.ugd = 1 AND b.status<2
              				AND a.id_reg=b.id_reg
              				AND b.`id_dokter_jaga`=d.`id_dokter`
              				AND b.id_pasien='".$id_pasien."'
            ) ax
            ORDER BY ax.id_eresep DESC
            ";
		*/
		// -------- NEW QUERY REBORN --------

		$sql = "SELECT 	c.`id_dokter`
										,(CASE WHEN f.`name` IS NOT NULL THEN f.`name`
											WHEN d.`name` IS NOT NULL THEN d.`name`
											ELSE e.name END) AS nama_dokter
										,a.*,b.*
						FROM 		soap_eresep a
										LEFT JOIN mst_dokter f ON (f.`id_dokter`=a.`id_dokter`)
										LEFT JOIN trx_reg_unit c ON (a.id_reg=c.id_reg AND DATE(a.eresepdate) = DATE(c.trxdate))
										LEFT JOIN mst_dokter d ON (c.`id_dokter`=d.`id_dokter`)
										, trx_reg b
										LEFT JOIN mst_dokter e ON (e.`id_dokter`=b.`id_dokter_prt1`)
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien='".$id_pasien."'
										
						ORDER BY a.id_eresep DESC";

		/*
		$sql = "SELECT ax.`id_dokter`,ax.nama_dokter, ax.*, ax.id_eresep, ax.eresepdate, ax.is_printed
            FROM (

              SELECT 	c.`id_dokter`,d.`name` AS nama_dokter,b.*, a.id_eresep, a.eresepdate, a.is_printed
              FROM 		soap_eresep a, trx_reg b ,trx_reg_unit c, mst_dokter d
              WHERE 	a.id_reg=b.id_reg
              AND a.id_reg=c.id_reg AND c.`id_dokter`=d.`id_dokter`
              AND b.id_pasien='".$id_pasien."'
							AND DATE(a.eresepdate) = DATE(c.trxdate)

              UNION ALL

              SELECT d.id_dokter, d.`name` AS nama_dokter,b.*, a.id_eresep, a.eresepdate, a.is_printed
              FROM soap_eresep a, trx_reg b, mst_dokter d

              WHERE b.ugd = 1 AND b.status<2
              AND a.id_reg=b.id_reg
              AND b.`id_dokter_jaga`=d.`id_dokter`
              AND b.id_pasien='".$id_pasien."'
            ) ax
            ORDER BY ax.id_eresep DESC
            ";
		*/
		$query = $this->dbhis->query($sql);
		$rs_eresep = $query->result_array();
		foreach($rs_eresep as $k => $v)
		{
			if($v['rwjn']=='1')
				$tipe_rawat = 'R.Jalan';
			elseif($v['rwip']=='1')
				$tipe_rawat = 'R.Inap';
			else
				$tipe_rawat = 'UGD';

			$rs_eresep[$k]['tipe_rawat'] = $tipe_rawat;
			### ----------------------------------------
			if($v['is_printed']=='1')
			{
				#$rs_eresep[$k]['fungsi'] 							= 'Sudah diproses';
				$rs_eresep[$k]['fungsi'] = '<a href="#" onClick="javascript : if(confirm(\'Batal eresep via telp?\')) cancel_eresep_by_phone(\''.$v['id_eresep'].'\');return false;">[ Hapus ]</a>';
				$rs_eresep[$k]['bgcolor_riw_eresep'] 	= '#FFC09F';
			}
			else
			{
				$rs_eresep[$k]['fungsi'] = '<a href="#" onClick="javascript : hapus_eresep_hangat(\''.$v['id_eresep'].'\');return false;"><i class="fa fa-trash" style="color:red;"></i></a>';
				$rs_eresep[$k]['bgcolor_riw_eresep'] 	= 'white';
			}
		}


		$sql_check_id_resep = "SELECT id_eresep FROM soap_eresep WHERE id_reg='$id_reg'";
		$queryideresep = $this->dbhis->query($sql_check_id_resep);
		$eresepid = $queryideresep->result_array();
		foreach($eresepid as $dtidresep){
			$id_eresep = $dtidresep['id_eresep'];
		}

		$data = array(
			'rs_eresep'		=> $rs_eresep,
			'id_reg'		=> $id_reg,
			'id_eresep'		=> $id_eresep
		);
		return $this->load->view('list_riwayat_resep_online', $data,$is_html);
	}

	public function list_riwayat_resep_online_farmasi($id_reg,$id_eresep,$is_html=false,$id_pasien)
	{

	$sql = "SELECT 	c.`id_dokter`
	,(CASE WHEN f.`name` IS NOT NULL THEN f.`name`
		WHEN d.`name` IS NOT NULL THEN d.`name`
		ELSE e.name END) AS nama_dokter,a.*,b.*
		FROM soap_eresep a
			LEFT JOIN mst_dokter f ON (f.`id_dokter`=a.`id_dokter`)
			LEFT JOIN trx_reg_unit c ON (a.id_reg=c.id_reg AND DATE(a.eresepdate) = DATE(c.trxdate))
			LEFT JOIN mst_dokter d ON (c.`id_dokter`=d.`id_dokter`), trx_reg b
			LEFT JOIN mst_dokter e ON (e.`id_dokter`=b.`id_dokter_prt1`)
		WHERE a.id_reg=b.id_reg AND b.id_pasien='".$id_pasien."' ORDER BY a.id_eresep DESC";
		$query = $this->dbhis->query($sql);
		$rs_eresep = $query->result_array();
		foreach($rs_eresep as $k => $v)
		{
			if($v['is_printed']=='1')
			{
				#$rs_eresep[$k]['fungsi'] 							= 'Sudah diproses';
				$rs_eresep[$k]['fungsi'] = '<a href="#" onClick="javascript : if(confirm(\'Batal eresep via telp?\')) cancel_eresep_by_phone(\''.$v['id_eresep'].'\');return false;">[ Hapus ]</a>';
				$rs_eresep[$k]['bgcolor_riw_eresep'] 	= '#FFC09F';
			}
			else
			{
				$rs_eresep[$k]['fungsi'] = '<a href="#" onClick="javascript : hapus_eresep_hangat(\''.$v['id_eresep'].'\');return false;"><i class="fa fa-trash" style="color:red;"></i></a>';
				$rs_eresep[$k]['bgcolor_riw_eresep'] 	= 'white';
			}
		}

		$data = array(
			'rs_eresep'		=> $rs_eresep,
			'id_reg'		=> $id_reg,
			'id_eresep'		=> $id_eresep
		);
		return $this->load->view('list_riwayat_resep_online_farmasi', $data,$is_html);
	}

	function list_riwayat_resep_online_det(){
		$id_eresep	                      = $this->input->post('id_eresep');
		$sql = "SELECT 	a.*,b.*
						FROM 		soap_eresep a, soap_eresep_det b
						WHERE 	a.id_eresep=b.id_eresep
										AND a.id_eresep='".$id_eresep."'
										AND b.is_racikan=0
						ORDER BY a.id_eresep DESC
						";
		$query = $this->dbhis->query($sql);
		$rs_eresep_det = $query->result_array();

		## ------ RACIKAN ----------------------------------------
		# --- head ---
		$sql = "SELECT 	a.*,b.*
						FROM 		soap_eresep a, soap_eresep_det b
						WHERE 	a.id_eresep=b.id_eresep
										AND a.id_eresep='".$id_eresep."'
										AND b.is_racikan=1
						ORDER BY a.id_eresep DESC
						";
		$query = $this->dbhis->query($sql);
		$rs_head = $query->result_array();
		foreach($rs_head as $k_racikan => $v_racikan)
		{
			# --- detail ---
			$sql = "SELECT 	b.*
							FROM 		soap_eresep_det a, soap_eresep_det_racikan b
							WHERE 	a.id_eresep_det=b.id_eresep_det
											AND a.id_eresep_det='".$v_racikan['id_eresep_det']."'
							";
			$query = $this->dbhis->query($sql);
			$rs_rck = $query->result_array();

			$rs_head[$k_racikan]['det_racikan'] = $rs_rck;
			#echo "<pre>".$sql."</pre>";
		}

		### --------- PERSIAPAN BUAT COPY OBAT ----------
		$tr_obat_biasa = '';
		foreach($rs_eresep_det as $k => $v)
		{
			$tr_obat_biasa .= '
			var rand_no	= get_random_number();
			var tpl_row_copy_biasa = \'\n\' +
				\' <tr id="\'+ rand_no +\'">	 \n \' +
				 \' <td>'.$v['name'].'<input type="hidden" name="ideresep[]" 				value="'.$id_eresep.'"><input type="hidden" name="obat[]" 				value="'.$v['name'].'"></td>	 \n \' +
				 \' <td>'.$v['jenis_obat'].'				<input type="hidden" name="jenis_obat[]" 	value="'.$v['jenis_obat'].'">		 \n \' +
				 \' 																<input type="hidden" name="id_fa[]" 			value="'.$v['id_trx_det'].'"></td>	\n \' +
				 \' <td>							<input type="text" name="qty[]" 				value="'.$v['qty'].'" class="inp-short"></td>		\n \' +
				 \' <td>						<input type="text" name="dosis[]" 			value="'.$v['dosis'].'" class="inp-medium"></td>		\n \' +
				 \' <td>				<input type="text" name="frekwensi[]" 	value="'.$v['frekwensi'].'" class="inp-medium"></td>		\n \' +
				 \' <td>				<input type="text" name="tme[]" 				value="'.$v['tme'].'" class="inp-medium"></td>		\n \' +
				 \' <td>				<input type="text" name="note[]" 				value="'.$v['note'].'" class="inp-medium"></td>		\n \' +
				 \' <td style="text-align:center;"><a href="#" onclick="javascript: if(confirm(\\\'Hapus ?\\\')) remove_row_draft(\\\'\'+ rand_no +\'\\\');return false;"><i class="fa fa-trash" style="color:red;"></i></a></td>		\n \' +
				\' </tr>		\n \' ;

				$( "#tbody_draft" ).append(tpl_row_copy_biasa);
				$("#butt_simpan_resep").removeClass("hidden");
				$("#batal_new_eresep").removeClass("hidden");
			';

		}

		$tr_header_racikan = '';
		foreach($rs_head as $k => $v)
		{

			$tr_header_racikan .= '
				var id_num = $( "#id_num" ).val();
				var num_resep_racikan = $( "#num_resep_racikan" ).val();
				var tpl_row_copy = \'\n\' +
					\' <tr id="row_racikan_\'+num_resep_racikan+\'"><td colspan="2">'.$v['name'].'	<input type="hidden" name="nama_racikan[\'+num_resep_racikan+\']" value="'.$v['name'].'"></td> \n \' +
						\' <td>											<input type="text" name="jumlah_racikan[\'+num_resep_racikan+\']" value="'.$v['qty'].'" class="inp-short"></td> \n \' +
						\' <td>											<input type="text" name="dosis_racikan[\'+num_resep_racikan+\']" value="'.$v['dosis'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="frekwensi_racikan[\'+num_resep_racikan+\']" value="'.$v['frekwensi'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="tme_racikan[\'+num_resep_racikan+\']" value="'.$v['tme'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="kemasan_racikan[\'+num_resep_racikan+\']" value="'.$v['jenis_obat'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="note_racikan[\'+num_resep_racikan+\']" value="'.$v['note'].'" class="inp-medium"></td> \n \' +
						\' <td style="text-align:center;"><a href="#" onclick="javascript: if(confirm(\\\'Hapus ?\\\')) remove_row_resep_racikan(\\\'\'+num_resep_racikan+\'\\\');return false;"><i class="fa fa-trash" style="color:red;"></i></a></td> \n \' +
					\' </tr>		\n \' ;
				$("#tbody_draft_resep_racikan").append(tpl_row_copy);
				console.log(id_num);
				';

				foreach($v['det_racikan'] as $kk => $vv)
				{
						$tr_header_racikan .= '
							var tpl_row_copy = \'\n\' +
										\'<tr class="row_racikan_det_\'+num_resep_racikan+\'">  \n \' +
											\'<td>&nbsp;&nbsp;&nbsp;'.$vv['name'].'				<input type="hidden" name="det_racikan_obat[\'+num_resep_racikan+\']['.$kk.']" 	value="'.$vv['name'].'"></td>  	\n \' +
											\'<td>&nbsp;&nbsp;&nbsp;'.$vv['jenis_obat'].'	<input type="hidden" name="det_jenis_obat[\'+num_resep_racikan+\']['.$kk.']" 		value="'.$vv['jenis_obat'].'">  	\n \' +
											\'																						<input type="hidden" name="det_id_fa[\'+num_resep_racikan+\']['.$kk.']" 				value="'.$vv['id_trx_det'].'"></td>  	\n \' +
											\'<td>				<input type="text" name="det_racikan_qty[\'+num_resep_racikan+\']['.$kk.']" 	value="'.$vv['qty'].'" class="inp-short"></td>  		\n \' +
											\'<td colspan="5">&nbsp;</td>  \n \' +
										\'</tr>		\n \' ;
							$("#tbody_draft_resep_racikan").append(tpl_row_copy); ';
				}

				$tr_header_racikan .= '
				$("#butt_simpan_resep").removeClass("hidden");
				$("#batal_new_eresep").removeClass("hidden");

				num_resep_racikan++;
				$( "#num_resep_racikan" ).val(num_resep_racikan);
				console.log(num_resep_racikan);

				$("#id_num").val("0");

			';

		}

		$data = array(
			'rs_eresep_det'			=> $rs_eresep_det,
			'id_eresep'					=> $id_eresep,
			'rs_head'						=> $rs_head,
			'tr_obat_biasa'			=> $tr_obat_biasa,
			'tr_header_racikan'	=> $tr_header_racikan,
		);

		$dataset = json_encode($data);
		echo $dataset;

	}



	public function inner_resep_detail($id_resep)
	{
		$sql = "SELECT 	a.*,b.name AS frekwensi,c.amount AS dosis,d.time AS time_time,d.`name` AS time_name
										,e.`id_src`
						FROM 		trx_frm_resep_det a
										LEFT JOIN `mst_farmalkes_etk_day` b ON (a.`qty_day`=b.`id`)
										LEFT JOIN `mst_farmalkes_etk_amt` c ON (a.`id_amt`=c.`id_amt`)
										LEFT JOIN `mst_farmalkes_etk_tme` d ON (a.`id_time`=d.`id_time`)
										,`mst_farmalkes` e
						WHERE 	a.`id_trx_det`=e.`id_fa`
										AND a.id_resep='".$id_resep."'
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$jenis_obat[0] = 'Oral';
		$jenis_obat[1] = 'Obat Luar';
		foreach($rs as $k => $v)
		{
			$rs[$k]['jenis_obat'] = $jenis_obat[$v['id_src']];
		}
		$data = array(
			'rs' 			=> $rs,
		);
		echo $this->load->view('riwayat_resep_det', $data, true);
	}

	public function add_new()
	{
		$id_reg	                      = $this->input->post('id_reg');
		$data_pasien	= $this->smartlib->get_data_pasien_by_id_reg($id_reg);
		$id_pasien = $data_pasien['id_pasien'];
		#$id_reg = $this->input->get('id_reg',true);
		$list_riwayat_resep_online = $this->list_riwayat_resep_online($id_reg,$is_html=true,$id_pasien);
		$data = array(
			'id_reg'								=> $id_reg,
			'id_pasien'								=> $id_pasien,
			'list_riwayat_resep_online'	=> $list_riwayat_resep_online
		);
		$this->load->view('eresep_add', $data);
	}

	public function add_additional()
	{
		$id_reg	                      = $this->input->post('id_reg');
		$id_eresep	                  = $this->input->post('id_eresep');
		$data_pasien	= $this->smartlib->get_data_pasien_by_id_reg($id_reg);
		$id_pasien = $data_pasien['id_pasien'];
		
        //detail obat & edit obat
		$prd_m = date('m');
		$prd_y = date('y');
		$sql = "SELECT 	a.*,b.*,c.sale_price,d.qty_end
		FROM soap_eresep a, soap_eresep_det b
		LEFT JOIN mst_farmalkes c ON b.id_trx_det=c.id_fa
		LEFT JOIN mst_farmalkes_avg d ON (c.id_fa=d.id_fa AND d.prd_m='$prd_m' AND d.prd_y='$prd_y')
		WHERE a.id_eresep=b.id_eresep
		AND a.id_eresep='".$id_eresep."'
		AND b.is_racikan=0
		ORDER BY a.id_eresep DESC";
		$query = $this->dbhis->query($sql);
		$rs_eresep_det = $query->result_array();

		## ------ RACIKAN ----------------------------------------
		# --- head ---
		$sql = "SELECT 	a.*,b.*
		FROM soap_eresep a, soap_eresep_det b
		WHERE a.id_eresep=b.id_eresep
 		AND a.id_eresep='".$id_eresep."'
		AND b.is_racikan=1
		ORDER BY a.id_eresep DESC";
		$query = $this->dbhis->query($sql);
		$rs_head = $query->result_array();
		foreach($rs_head as $k_racikan => $v_racikan)
		{
			# --- detail ---
			$sql = "SELECT b.*,c.sale_price,d.qty_end
					FROM soap_eresep_det a, soap_eresep_det_racikan b
					LEFT JOIN mst_farmalkes c ON b.id_trx_det=c.id_fa
					LEFT JOIN mst_farmalkes_avg d ON (c.id_fa=d.id_fa AND d.prd_m='$prd_m' AND d.prd_y='$prd_y')
					WHERE a.id_eresep_det=b.id_eresep_det
					AND a.id_eresep_det='".$v_racikan['id_eresep_det']."'";
			$query = $this->dbhis->query($sql);
			$rs_rck = $query->result_array();

			$rs_head[$k_racikan]['det_racikan'] = $rs_rck;
			//echo "<pre>".$sql."</pre>";
		}

		### --------- PERSIAPAN BUAT COPY OBAT ----------
		$tr_obat_biasa = '';
		foreach($rs_eresep_det as $k => $v)
		{
			$tr_obat_biasa .= '
			var rand_no	= get_random_number();
			var tpl_row_copy_biasa = \'\n\' +
				\' <tr id="\'+ rand_no +\'">	 \n \' +
				 \' <td>'.$v['name'].'<input type="hidden" name="ideresep[]" value="'.$id_eresep.'"><input type="hidden" name="obat[]" value="'.$v['name'].'"></td>	 \n \' +
				 \' <td>'.$v['jenis_obat'].' <input type="hidden" name="jenis_obat[]" 	value="'.$v['jenis_obat'].'">		 \n \' +
				 \' <input type="hidden" name="id_fa[]" value="'.$v['id_trx_det'].'"></td> \n \' +
				 \' <td><input type="text" name="qty[]" value="'.$v['qty'].'" class="inp-short"></td> \n \' +
				 \' <td> <input type="text" name="dosis[]" value="'.$v['dosis'].'" class="inp-medium"></td> \n \' +
				 \' <td> <input type="text" name="frekwensi[]" value="'.$v['frekwensi'].'" class="inp-medium"></td> \n \' +
				 \' <td> <input type="text" name="tme[]" value="'.$v['tme'].'" class="inp-medium"></td> \n \' +
				 \' <td> <input type="text" name="note[]" value="'.$v['note'].'" class="inp-medium"></td> \n \' +
				 \' <td style="text-align:center;"><a href="#" onclick="javascript: if(confirm(\\\'Hapus ?\\\')) remove_row_draft(\\\'\'+ rand_no +\'\\\');return false;"><i class="fa fa-trash" style="color:red;"></i></a></td> \n \' +
				\' </tr> \n \' ;

				$( "#tbody_draft" ).append(tpl_row_copy_biasa);
				$("#butt_simpan_resep").removeClass("hidden");
				$("#batal_new_eresep").removeClass("hidden");
			';

		}

		$tr_header_racikan = '';
		foreach($rs_head as $k => $v)
		{

			$tr_header_racikan .= '
				var id_num = $( "#id_num" ).val();
				var num_resep_racikan = $( "#num_resep_racikan" ).val();
				var tpl_row_copy = \'\n\' +
					\' <tr id="row_racikan_\'+num_resep_racikan+\'"><td colspan="2">'.$v['name'].'	<input type="hidden" name="nama_racikan[\'+num_resep_racikan+\']" value="'.$v['name'].'"></td> \n \' +
						\' <td>											<input type="text" name="jumlah_racikan[\'+num_resep_racikan+\']" value="'.$v['qty'].'" class="inp-short"></td> \n \' +
						\' <td>											<input type="text" name="dosis_racikan[\'+num_resep_racikan+\']" value="'.$v['dosis'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="frekwensi_racikan[\'+num_resep_racikan+\']" value="'.$v['frekwensi'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="tme_racikan[\'+num_resep_racikan+\']" value="'.$v['tme'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="kemasan_racikan[\'+num_resep_racikan+\']" value="'.$v['jenis_obat'].'" class="inp-medium"></td> \n \' +
						\' <td>											<input type="text" name="note_racikan[\'+num_resep_racikan+\']" value="'.$v['note'].'" class="inp-medium"></td> \n \' +
						\' <td style="text-align:center;"><a href="#" onclick="javascript: if(confirm(\\\'Hapus ?\\\')) remove_row_resep_racikan(\\\'\'+num_resep_racikan+\'\\\');return false;"><i class="fa fa-trash" style="color:red;"></i></a></td> \n \' +
					\' </tr>		\n \' ;
				$("#tbody_draft_resep_racikan").append(tpl_row_copy);
				console.log(id_num);
				';

				foreach($v['det_racikan'] as $kk => $vv)
				{
						$tr_header_racikan .= '
							var tpl_row_copy = \'\n\' +
										\'<tr class="row_racikan_det_\'+num_resep_racikan+\'">  \n \' +
											\'<td>&nbsp;&nbsp;&nbsp;'.$vv['name'].'				<input type="hidden" name="det_racikan_obat[\'+num_resep_racikan+\']['.$kk.']" 	value="'.$vv['name'].'"></td>  	\n \' +
											\'<td>&nbsp;&nbsp;&nbsp;'.$vv['jenis_obat'].'	<input type="hidden" name="det_jenis_obat[\'+num_resep_racikan+\']['.$kk.']" 		value="'.$vv['jenis_obat'].'">  	\n \' +
											\'																						<input type="hidden" name="det_id_fa[\'+num_resep_racikan+\']['.$kk.']" 				value="'.$vv['id_trx_det'].'"></td>  	\n \' +
											\'<td>				<input type="text" name="det_racikan_qty[\'+num_resep_racikan+\']['.$kk.']" 	value="'.$vv['qty'].'" class="inp-short"></td>  		\n \' +
											\'<td colspan="5">&nbsp;</td>  \n \' +
										\'</tr>		\n \' ;
							$("#tbody_draft_resep_racikan").append(tpl_row_copy); ';
				}

				$tr_header_racikan .= '
				$("#butt_simpan_resep").removeClass("hidden");
				$("#batal_new_eresep").removeClass("hidden");

				num_resep_racikan++;
				$( "#num_resep_racikan" ).val(num_resep_racikan);
				console.log(num_resep_racikan);

				$("#id_num").val("0");

			';

		}
        //end detail obat & edit obat

        //tambah obat

        //end tambah obat

		$setting_harga = $this->Eresep_model->mst_setting_harga();
		$tuslah      = $setting_harga->tuslah;
		$racik		 = $setting_harga->jasa_racik;

		$data = array(
			'id_reg'			=> $id_reg,
			'id_pasien'			=> $id_pasien,
			'id_eresep'			=> $id_eresep,
            'rs_eresep_det'		=> $rs_eresep_det,
			'rs_head'			=> $rs_head,
			'tr_obat_biasa'		=> $tr_obat_biasa,
			'tr_header_racikan'	=> $tr_header_racikan,
			'tuslah'			=> $tuslah,
			'racik'				=> $racik
		);
		$this->load->view('eresep_additional', $data);
	}

	public function inner_get_data_autocomplet_obat()
	{
		$term = $this->input->get('term',true);

		$sql = "SELECT 	a.id_fa,a.`name`,a.id_src
						FROM 		mst_farmalkes a
						WHERE 	UPPER(a.name) LIKE '%".strtoupper($term)."%'
										AND a.aktif = 1
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$jenis_obat[0] = 'Oral';
		$jenis_obat[1] = 'Obat Luar';
		foreach($rs as $k => $v)
		{
			$rs[$k]['jenis_obat'] = $jenis_obat[$v['id_src']];
			$rs[$k]['label'] = $v['name'];
			$rs[$k]['id'] = $v['id_fa'];
		}
		$obat = json_encode($rs);
		echo $obat;
	}

	public function inner_get_data_autocomplet_obat_dosis()
	{
		$term = $this->input->get('term',true);

		$sql = "SELECT 	a.`id_amt` AS id
										,CONCAT(a.`amount`,' ',a.`satuan`) AS label
						FROM		`mst_farmalkes_etk_amt` a
						WHERE 	a.`aktif`=1 AND UPPER(CONCAT(a.`amount`,' ',a.`satuan`)) LIKE '%".strtoupper($term)."%'
						ORDER BY a.`satuan`,a.`amount`
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$dosis = json_encode($rs);
		echo $dosis;
	}

	public function inner_get_data_autocomplet_obat_frekwensi()
	{
		$term = $this->input->get('term',true);

		$sql = "SELECT 	a.`id`,a.`name` AS label
						FROM		`mst_farmalkes_etk_day` a
						ORDER BY a.name
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$frekwensi = json_encode($rs);
		echo $frekwensi;
	}

	public function inner_get_data_autocomplet_obat_tme()
	{
		$term = $this->input->get('term',true);

		$sql = "SELECT 	DISTINCT a.`id_time` AS id
										,a.`name` AS label
						FROM		`mst_farmalkes_etk_tme` a
						WHERE 	a.`aktif`=1 AND UPPER(a.`name`) LIKE '%".strtoupper($term)."%'
						ORDER BY a.`name`
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$tme = json_encode($rs);
		echo $tme;
	}

	public function inner_get_data_autocomplet_nama_dokter()
	{
		$term = $this->input->get('term',true);

		$sql = "SELECT 	a.`id_dokter` AS id,a.`name` AS label
						FROM		`mst_dokter` a
						WHERE 	UPPER(a.`name`) LIKE '%".strtoupper($term)."%'
						ORDER BY a.`name`
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$dokter = json_encode($rs);
		echo $dokter;
	}



	public function save_eresep_additional()
	{
		## --- data header ---
		$id_reg = $this->input->post('id_reg',true);
		$id_pasien = $this->input->post('id_pasien',true);
		$now = date('Y-m-d H:i:s');

		$is_eresep_pulang = intval($this->input->post('is_eresep_pulang',true));

		## --- data detail ---
		$ideresep 				= $this->input->post('ideresep',true);
		$obat 					= $this->input->post('obat',true);
		$id_fa 					= $this->input->post('id_fa',true);
		$jenis_obat 			= $this->input->post('jenis_obat',true);
		$qty 					= $this->input->post('qty',true);
		$dosis 					= $this->input->post('dosis',true);
		$frekwensi 				= $this->input->post('frekwensi',true);
		$tme 					= $this->input->post('tme',true);
		$note 					= $this->input->post('note',true);

		## ---  data racikan ; headernya ------------------
		$nama_racikan 			= $this->input->post('nama_racikan',true);
		$jumlah_racikan 		= $this->input->post('jumlah_racikan',true);
		$dosis_racikan 			= $this->input->post('dosis_racikan',true);
		$frekwensi_racikan 		= $this->input->post('frekwensi_racikan',true);
		$tme_racikan 			= $this->input->post('tme_racikan',true);
		$kemasan_racikan 		= $this->input->post('kemasan_racikan',true);
		$note_racikan 			= $this->input->post('note_racikan',true);
		## contoh format : nama_racikan[0]

		## ---  data racikan detail ; detailnya ------------------
		$det_racikan_obat 		= $this->input->post('det_racikan_obat',true);
		$det_id_fa 				= $this->input->post('det_id_fa',true);
		$det_jenis_obat 		= $this->input->post('det_jenis_obat',true);
		$det_racikan_qty 		= $this->input->post('det_racikan_qty',true);
		#$det_racikan_dosis 	= $this->input->post('det_racikan_dosis',true);

		$datetime=date('Y-m-d H:i:s');

		$id_dokter_penginput = $this->session->userdata['sp']->id_dokter;
		    //set increment nya
				$datanu       	= $this->Eresep_model->dnu();
				$setnourut		= $datanu->nourut;
				$urutan 		= (int) substr($setnourut, 4, 5);
				$setincrement 	= $urutan+1;
				$increset		= date('m').date('y').sprintf("%05s", $setincrement);
				//echo "011400001"."<br>";
				//echo $increset;
			//end set increment nya

			//exit;
		### --- GET id_eresep ---------------------------------
		$id_eresep 	= $ideresep[0];
		### --- UPDATE eresep ---------------------------------
		//$deleresep_1 = "DELETE FROM soap_eresep WHERE id_eresep='$ideresep[0]'";
		//$this->dbhis->query($deleresep_1);
		$deleresep_2 = "DELETE FROM soap_eresep_det WHERE id_eresep='$id_eresep'";
		$this->dbhis->query($deleresep_2);
		$deleresep_3 = "DELETE FROM soap_eresep_det_racikan WHERE id_eresep='$id_eresep'";
		$this->dbhis->query($deleresep_3);



		### --- INSERT eresep detail ---------------------------------
		if(isset($obat)){
			foreach($obat as $k => $v){
				$sql_insert_det = "INSERT INTO `soap_eresep_det` (`id_eresep`, `id_trx_det`, `name`, `jenis_obat`, `qty`, `dosis`, `tme`, `frekwensi`, `note`) VALUES('".$id_eresep."','".$id_fa[$k]."','".$obat[$k]."','".$jenis_obat[$k]."','".$qty[$k]."','".$dosis[$k]."','".$tme[$k]."','".$frekwensi[$k]."','".$note[$k]."')";
				$this->dbhis->query($sql_insert_det);
			}
		}

		if(isset($nama_racikan)){
			foreach($nama_racikan as $k => $v){
				#### dibawah ini masukin header racikan di detail resep ---------
				$sql_insert_det = "INSERT INTO `soap_eresep_det` (`id_eresep`,`id_trx_det`,`name`,`jenis_obat`,`qty`,`dosis`,`tme`,`frekwensi`,`note`,`is_racikan`) VALUES('".$id_eresep."',0,'".$v."','".$kemasan_racikan[$k]."','".$jumlah_racikan[$k]."','".$dosis_racikan[$k]."','".$tme_racikan[$k]."','".$frekwensi_racikan[$k]."','".$note_racikan[$k]."',1)";
				$this->dbhis->query($sql_insert_det);

				### --- GET id_eresep ---------------------------------
				$sql 						= "SELECT LAST_INSERT_ID() as id_eresep_det";
				$query 					= $this->dbhis->query($sql);
				$rs 						= $query->row_array();
				$id_eresep_det 	= $rs['id_eresep_det'];
				foreach($det_racikan_obat[$k] as $kk => $vv){
					$sql_insert_det_racikan = "INSERT INTO `soap_eresep_det_racikan` (`id_eresep_det`,`id_eresep`,`id_trx_det`,`name`,`jenis_obat`,`qty`) VALUES('".$id_eresep_det."','".$id_eresep."','".$det_id_fa[$k][$kk]."','".$vv."','".$det_jenis_obat[$k][$kk]."','".$det_racikan_qty[$k][$kk]."')";
					$this->dbhis->query($sql_insert_det_racikan);
				}
			}//exit;
		}
		//echo "<script language=\"javascript\">swal.fire({title: 'Good job', text: 'You clicked the button!', type: 'success'}).then(function(){ location.reload();});</script>";
		//echo "<script language=\"javascript\">location.reload();</script>";
		echo "<script language=\"javascript\">swal.fire('Berhasil!','Resep Berhasil Dibuat!', 'success')</script>";
		echo $this->add_additional($id_reg,$id_pasien);
	}

	public function print_eresep($id_eresep)
	{
		$rs_info 	= $this->smartlib->rs_info();
		$nama_rs	= $rs_info['nama_rs'];
		$alamat_rs	= $rs_info['alamat_rs'];
		$telp_rs	= $rs_info['telp_rs'];
		$fax_rs		= $rs_info['fax_rs'];

		/*
		$sql = "SELECT 	a.*,d.*,d.name AS nama_pasien
										-- ,IFNULL(e.`name`,f.`name`) AS dokter
										,IFNULL(h.name,e.`name`) AS dokter
										-- ,e.acc_branch AS sip
										,IF(h.name IS NOT NULL,h.acc_branch,e.acc_branch) AS sip
						FROM 		soap_eresep a
										LEFT JOIN mst_dokter h ON (h.`id_dokter`=a.`id_dokter`)
										,trx_reg b
										LEFT JOIN trx_reg_unit c ON (c.id_reg=b.id_reg)
										LEFT JOIN mst_dokter e ON (e.`id_dokter`=c.`id_dokter`)
										LEFT JOIN mst_dokter f ON (f.`id_dokter`=b.`id_dokter_jaga`)
										,mst_pasien d
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien=d.id_pasien
										AND a.id_eresep='".$id_eresep."'
						";
		*/
		$sql = "-- RAWAT JALAN / RAWAT INAP --
						SELECT 	a.*,d.*,d.name AS nama_pasien
										,IFNULL(h.name,e.`name`) AS dokter
										,IF(h.name IS NOT NULL,k.sip_str,i.sip_str) AS sip 
										,IFNULL(c.`id_dokter`, b.`id_dokter_jaga`) AS kodedokter 
										,(CASE WHEN b.rwip=1 THEN 'RI' ELSE 'RJ' END) AS tipe_rawat
						FROM 		soap_eresep a
										LEFT JOIN mst_dokter h ON (h.`id_dokter`=a.`id_dokter`)
										LEFT JOIN smart_login k ON (k.`id_dokter`=a.`id_dokter`)
										,trx_reg b
										LEFT JOIN trx_reg_unit c ON (c.id_reg=b.id_reg)
										LEFT JOIN mst_dokter e ON (e.`id_dokter`=c.`id_dokter`)
										LEFT JOIN smart_login i ON (i.`id_dokter`=c.`id_dokter`)
										LEFT JOIN mst_dokter f ON (f.`id_dokter`=b.`id_dokter_jaga`)
										LEFT JOIN smart_login j ON (j.`id_dokter`=b.`id_dokter_jaga`)
										,mst_pasien d
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien=d.id_pasien
										AND a.id_eresep='".$id_eresep."'";
		$query 	= $this->dbhis->query($sql);
		$rs 		= $query->row_array();

    $id_reg = $rs['id_reg'];
    $id_pasien = $rs['id_pasien'];
		$tipe_rawat = $rs['tipe_rawat'];

    $riwayat_pasien 	= $this->smartlib->riwayat_pasien($id_pasien);

		$pasien = $this->smartlib->get_data_registrasi_by_id_reg($id_reg);
		if($tipe_rawat=='RI')
		{
    	$alergi = $this->smartlib->get_alergi_pasien_ri($id_reg);
			$pasien['poli_ruangan'] = $this->smartlib->get_ruangan_pasien($id_reg);
		}
		else
		{
			$alergi = $this->smartlib->get_alergi_pasien_rj_igd($id_reg);
		}
		$soap 	= $this->Eresep_model->get_data_soap($id_reg);

		$sql 		= "SELECT a.* FROM soap_eresep_det a WHERE a.id_eresep='".$id_eresep."'";
		$query 	= $this->dbhis->query($sql);
		$rs_det = $query->result_array();
		$jum_resep = $query->num_rows();
		foreach($rs_det as $k => $v)
		{
			$rs_det[$k]['qty_romawi']	= $this->numberToRomanRepresentation($v['qty']);
			$rs_det[$k]['name_alt'] = $this->frekwensi2name_alt($v['frekwensi']);
			if($v['is_racikan']==1)
			{
				$sql 						= "SELECT a.* FROM soap_eresep_det_racikan a WHERE a.id_eresep_det='".$v['id_eresep_det']."'";
				$query 					= $this->dbhis->query($sql);
				$rs_det_racikan = $query->result_array();
				$rs_det[$k]['racikan'] = $rs_det_racikan;
			}
		}

		// -- UPDATE yg sudah diprint --
		$sql = "UPDATE soap_eresep SET is_printed=1 WHERE id_eresep='".$id_eresep."'";
		$query 	= $this->dbhis->query($sql);

		$this->antrolib->updateWaktuAntreanWithIdreg($id_reg, $rs['kodedokter'], 6);
		$this->antrolib->updateWaktuAntreanWithIdreg($id_reg, $rs['kodedokter'], 7);

		$data = array(
			'rs' 		=> $rs,
			'rs_det' 	=> $rs_det,
			'jum_resep'	=> $jum_resep,
			'pasien'	=> $pasien,
			'soap'		=> $soap,
      'alergi'		=> $alergi,

			'nama_rs'		=> $nama_rs,
			'alamat_rs'	=> $alamat_rs,
			'telp_rs'		=> $telp_rs,
			'fax_rs'		=> $fax_rs,
      'riwayat_pasien'	=> $riwayat_pasien,
		);
		$this->load->view('print_eresep', $data);
	}

	function frekwensi2name_alt($frek)
	{
		$sql = "SELECT a.name_alt FROM mst_farmalkes_etk_day a WHERE name = '".$frek."'";
		$query 			= $this->dbhis->query($sql);
		$rs 				= $query->row_array();
		$name_alt 	= $rs['name_alt'];

		if($name_alt!='')
			$name_alt = $name_alt;
		else
			$name_alt = $frek;

		return $name_alt;
	}

	function numberToRomanRepresentation($number)
	{
		$map = array('M' => 1000, 'CM' => 900, 'D' => 500, 'CD' => 400, 'C' => 100, 'XC' => 90, 'L' => 50, 'XL' => 40, 'X' => 10, 'IX' => 9, 'V' => 5, 'IV' => 4, 'I' => 1);
		$returnValue = '';
		while ($number > 0) {
				foreach ($map as $roman => $int) {
						if($number >= $int) {
								$number -= $int;
								$returnValue .= $roman;
								break;
						}
				}
		}
		return $returnValue;
	}

	public function mst_tpl_racikan()
	{
		$id_dokter = $this->session->userdata['sp']->id_dokter;

		$this->make_bread->add('Master Admin', '', 1);
    $this->make_bread->add('Template Racikan', '', 0);
    $breadcrumb = $this->make_bread->output();

		$sql = "SELECT 	a.*,b.name AS nama_dokter
						FROM 		soap_eresep_tpl_racikan a
										LEFT JOIN mst_dokter b ON (a.id_dokter=b.id_dokter)
						WHERE b.aktif = 1
						";
		if($id_dokter!='')
			$sql .= " AND a.id_dokter=".$id_dokter." ";

		$query = $this->dbhis->query($sql);
		$rs = $query->result();

		$data = array(
			'rs' 	=> $rs,
			'breadcrumb' 	=> $breadcrumb,
		);
		$this->load->view('vmst_tpl_racikan', $data);
	}

	public function mst_tpl_racikan_add()
	{
		$this->make_bread->add('Dokter', '', 1);
    $this->make_bread->add('Master Template Racikan', '', 0);
    $breadcrumb = $this->make_bread->output();

		$data = array(
			'breadcrumb'	=> $breadcrumb,
		);
		$this->load->view('vmst_tpl_racikan_add', $data);
	}



	public function inner_tpl_racikan_detail($id_tpl_racikan)
	{
		$sql = "SELECT 	a.*,b.name AS nama_dokter
						FROM 		soap_eresep_tpl_racikan a
										LEFT JOIN mst_dokter b ON (a.id_dokter=b.id_dokter)
						WHERE		a.id_tpl_racikan='".$id_tpl_racikan."'
						";
		$query = $this->dbhis->query($sql);
		$rs_head = $query->row_array();

		$sql = "SELECT 	b.*
						FROM 		soap_eresep_tpl_racikan a, soap_eresep_tpl_racikan_det b
						WHERE 	a.id_tpl_racikan=b.id_tpl_racikan
										AND a.id_tpl_racikan='".$id_tpl_racikan."'
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$data = array(
			'rs' 			=> $rs,
			'rs_head' => $rs_head,
		);
		echo $this->load->view('vmst_inner_tpl_racikan_det', $data, true);
	}

	public function display_eresep_farmasi($tipe='rj')
	{
		$sql = "SELECT 	a.*,b.id_pasien,d.name AS nama_pasien
										,IFNULL(h.name,e.`name`) AS dokter
										,(SELECT 1 FROM soap_eresep_det x WHERE x.is_racikan=1 AND x.id_eresep=a.id_eresep LIMIT 1) AS is_racikan
										,g.name AS penjamin
						FROM 		soap_eresep a
										LEFT JOIN mst_dokter h ON (h.`id_dokter`=a.`id_dokter`)
										LEFT JOIN trx_reg_unit c ON (c.id_reg=a.id_reg AND DATE(a.eresepdate) = DATE(c.trxdate))
										LEFT JOIN mst_dokter e ON (e.`id_dokter`=c.`id_dokter`)
										,trx_reg b
										LEFT JOIN mst_company g ON (g.id_company=b.id_asuransi)
										LEFT JOIN mst_dokter f ON (f.`id_dokter`=b.`id_dokter_jaga`)
										,mst_pasien d
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien=d.id_pasien
										AND a.`eresepdate` >= (NOW() - INTERVAL 12 HOUR)
										
										";
		
										
		$sql .= ($tipe=='rj') ? " AND b.rwip=0 " : " AND b.rwip=1 ";
		$sql .= "
					ORDER BY a.id_eresep DESC ";
		#echo "<pre>".$sql."</pre>";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		foreach($rs as $k => $v)
		{
			if($v['is_printed']=='1')
				$bgcolor = '#F4BCBD';
			else
				$bgcolor = '';

			$rs[$k]['bgcolor'] = $bgcolor;

			$rs[$k]['jenis_kemasan'] = ($v['is_racikan']=='1')?'Racikan':'Non - Racikan';
		}

		$text_tipe['rj'] = "Rawat Jalan";
		$text_tipe['ri'] = "Rawat Inap";
		$data = array(
			'rs' 		=> $rs,
			'text_tipe'	=> $text_tipe[$tipe],
		);
		$this->load->view('display_eresep_farmasi', $data);
	}

	public function display_eresep_farmasi_cari_xxx()
	{
		$id_pasien_cari		= $this->input->get('id_pasien_cari');
		$nama_pasien_cari	= $this->input->get('nama_pasien_cari');

		$this->make_bread->add('Farmasi', '', 1);
    $this->make_bread->add('Pencarian Resep', '', 0);
    $breadcrumb = $this->make_bread->output();

		if(empty($id_pasien_cari) && empty($nama_pasien_cari))
		{
			$data = array(
				'rs'								=> array(),
				'id_pasien_cari'		=> $id_pasien_cari,
				'nama_pasien_cari' 	=> $nama_pasien_cari,
				'breadcrumb' 				=> $breadcrumb,
			);
			$this->load->view('display_eresep_farmasi_cari',$data);
			return;
		}

		$sql = "SELECT 	a.*,b.id_pasien,d.name AS nama_pasien, IFNULL(e.`name`, f.`name`) AS dokter
										,(SELECT 1 FROM soap_eresep_det x WHERE x.is_racikan=1 AND x.id_eresep=a.id_eresep LIMIT 1) AS is_racikan
										,g.name AS penjamin
						FROM 		soap_eresep a
										,trx_reg b
										LEFT JOIN mst_company g ON (g.id_company=b.id_asuransi)
										LEFT JOIN trx_reg_unit c ON (c.id_reg=b.id_reg)
										LEFT JOIN mst_dokter e ON (e.`id_dokter`=c.`id_dokter`)
										LEFT JOIN mst_dokter f ON (f.`id_dokter`=b.`id_dokter_jaga`)
										,mst_pasien d
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien=d.id_pasien
										";
			if($id_pasien_cari != '')
				$sql.=" AND b.id_pasien =".intval($id_pasien_cari)."
				";
			if ($nama_pasien_cari != '')
				$sql.=" AND LOWER(b.name) LIKE LOWER('%".$nama_pasien_cari."%')
				";

		$sql .= " ORDER BY a.id_eresep DESC
							LIMIT 100
						";
		#echo "<pre>".$sql."</pre>";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		foreach($rs as $k => $v)
		{
			if($v['is_printed']=='1')
				$bgcolor = '#F4BCBD';
			else
				$bgcolor = '';

			$rs[$k]['bgcolor'] = $bgcolor;

			$rs[$k]['jenis_kemasan'] = ($v['is_racikan']=='1')?'Racikan':'Non - Racikan';
		}
		$data = array(
			'rs' 	=> $rs,
			'breadcrumb' 	=> $breadcrumb,
		);
		$this->load->view('display_eresep_farmasi_cari', $data);
	}

	public function display_eresep_farmasi_cari()
	{
		$id_pasien_cari		= $this->input->post('id_pasien_cari');
		$nama_pasien_cari	= $this->input->post('nama_pasien_cari');

		$this->make_bread->add('Farmasi', '', 1);
    $this->make_bread->add('Pencarian Resep', '', 0);
    $breadcrumb = $this->make_bread->output();

		if(empty($id_pasien_cari) && empty($nama_pasien_cari))
		{
			$data = array(
				'rs'								=> array(),
				'id_pasien_cari'		=> $id_pasien_cari,
				'nama_pasien_cari' 	=> $nama_pasien_cari,
				'breadcrumb' 				=> $breadcrumb,
			);
			$this->load->view('display_eresep_farmasi_cari',$data);
			return;
		}

		$sql = "SELECT 	MP.id_pasien, MP.name AS pasien, TR.id_reg,
										MC.name AS asuransi, TR.regdate , MD.name AS dokter
										,SE.id_eresep
						FROM 		`trx_reg` TR
						LEFT JOIN trx_reg_unit TRU ON TR.id_reg = TRU.id_reg
						LEFT JOIN mst_pasien MP ON TR.id_pasien=MP.id_pasien
						LEFT JOIN mst_company MC ON TR.id_asuransi=MC.id_company
						LEFT JOIN mst_dokter MD ON TRU.id_dokter = MD.id_dokter
						JOIN soap_eresep SE ON TR.id_reg = SE.id_reg

						WHERE (TR.`rwjn` = 1 OR TR.`ugd`='1')
						";
			if($id_pasien_cari != '')
				$sql.=" AND TR.id_pasien =".intval($id_pasien_cari)."
				";
			if ($nama_pasien_cari != '')
				$sql.=" AND LOWER(MP.name) LIKE LOWER('%".$nama_pasien_cari."%')
				";
			$sql .= " ORDER BY TR.regdate DESC";
		#echo "<pre>".$sql."</pre>";
		$query= $this->dbhis->query($sql);
		$rs 	= $query->result_array();

		foreach($rs as $k => $v)
		{

		}

		$data = array(
			'rs' 	=> $rs,
			'id_pasien_cari'		=> $id_pasien_cari,
			'nama_pasien_cari' 	=> $nama_pasien_cari,
			'breadcrumb' 	=> $breadcrumb,
		);
		$this->load->view('display_eresep_farmasi_cari', $data);
	}

	public function display_eresep_farmasi_cari_ranap()
	{
		$id_pasien_cari		= $this->input->post('id_pasien_cari');
		$nama_pasien_cari	= $this->input->post('nama_pasien_cari');

		$this->make_bread->add('Farmasi', '', 1);
    $this->make_bread->add('Pencarian Resep', '', 0);
    $breadcrumb = $this->make_bread->output();

		if(empty($id_pasien_cari) && empty($nama_pasien_cari))
		{
			$data = array(
				'rs'								=> array(),
				'id_pasien_cari'		=> $id_pasien_cari,
				'nama_pasien_cari' 	=> $nama_pasien_cari,
				'breadcrumb' 				=> $breadcrumb,
			);
			$this->load->view('display_eresep_farmasi_cari_ranap',$data);
			return;
		}

		$sql = "SELECT 	MP.id_pasien, MP.name AS pasien, TR.id_reg,
										MC.name AS asuransi, TR.regdate , MD.name AS dokter
										,SE.id_eresep
						FROM 		`trx_reg` TR
						LEFT JOIN trx_reg_unit TRU ON TR.id_reg = TRU.id_reg
						LEFT JOIN mst_pasien MP ON TR.id_pasien=MP.id_pasien
						LEFT JOIN mst_company MC ON TR.id_asuransi=MC.id_company
						LEFT JOIN mst_dokter MD ON TRU.id_dokter = MD.id_dokter
						JOIN soap_eresep SE ON TR.id_reg = SE.id_reg

						WHERE TR.`rwip` = 1
						";
			if($id_pasien_cari != '')
				$sql.=" AND TR.id_pasien =".intval($id_pasien_cari)."
				";
			if ($nama_pasien_cari != '')
				$sql.=" AND LOWER(MP.name) LIKE LOWER('%".$nama_pasien_cari."%')
				";
			$sql .= " ORDER BY TR.regdate DESC";
		#echo "<pre>".$sql."</pre>";
		$query= $this->dbhis->query($sql);
		$rs 	= $query->result_array();

		foreach($rs as $k => $v)
		{

		}

		$data = array(
			'rs' 	=> $rs,
			'id_pasien_cari'		=> $id_pasien_cari,
			'nama_pasien_cari' 	=> $nama_pasien_cari,
			'breadcrumb' 	=> $breadcrumb,
		);
		$this->load->view('display_eresep_farmasi_cari_ranap', $data);
	}

	public function inner_pick_tpl_racikan_list()
	{
		$is_doctor	= @$this->session->userdata['sp']->id_role;
		$id_dokter	= @$this->session->userdata['sp']->id_dokter;

		$sql = "SELECT 	a.*,b.name AS nama_dokter
						FROM 		soap_eresep_tpl_racikan a
										LEFT JOIN mst_dokter b ON (a.id_dokter=b.id_dokter)
						WHERE b.aktif = 1
						";
		if($is_doctor == 2){
			$sql.="AND b.id_dokter ='$id_dokter'";
		}

		$query = $this->dbhis->query($sql);
		$rs = $query->result();

		$data = array(
			'rs' 	=> $rs,
		);
		$this->load->view('vinner_pick_tpl_racikan_list', $data);
	}

	public function inner_pick_tpl_racikan_detail($id_tpl_racikan)
	{
		$sql = "SELECT 	a.*,b.name AS nama_dokter
						FROM 		soap_eresep_tpl_racikan a
										LEFT JOIN mst_dokter b ON (a.id_dokter=b.id_dokter)
						WHERE		a.id_tpl_racikan='".$id_tpl_racikan."'
						";
		$query = $this->dbhis->query($sql);
		$rs_head = $query->row_array();

		$sql = "SELECT 	b.*
						FROM 		soap_eresep_tpl_racikan a, soap_eresep_tpl_racikan_det b
						WHERE 	a.id_tpl_racikan=b.id_tpl_racikan
										AND a.id_tpl_racikan='".$id_tpl_racikan."'
						";
		$query = $this->dbhis->query($sql);
		$rs = $query->result_array();
		$data = array(
			'rs' 			=> $rs,
			'rs_head' => $rs_head,
		);
		echo $this->load->view('vinner_pick_tpl_racikan_detail', $data, true);
	}

	function remove_eresep_hangat($id_eresep)
	{
		$oke = '';
		$sql = "SELECT * FROM soap_eresep a WHERE a.id_eresep='".$id_eresep."' AND a.is_printed=0";
		$query = $this->dbhis->query($sql);
		$jum_data = $query->num_rows();
		if($jum_data>0)
		{
			$sql = "DELETE FROM soap_eresep_det_racikan WHERE id_eresep='".$id_eresep."'";
			$ok3 = $this->dbhis->query($sql);

			$sql = "DELETE FROM soap_eresep_det WHERE id_eresep='".$id_eresep."'";
			$ok2 = $this->dbhis->query($sql);

			$sql = "DELETE FROM soap_eresep WHERE id_eresep='".$id_eresep."'";
			$ok1 = $this->dbhis->query($sql);

			$oke = 'ok';
		}
		echo $oke;
	}

	function cancel_eresep_by_phone($id_eresep)
	{
		$oke = '';

		$sql = "DELETE FROM soap_eresep_det_racikan WHERE id_eresep='".$id_eresep."'";
		$ok3 = $this->dbhis->query($sql);

		$sql = "DELETE FROM soap_eresep_det WHERE id_eresep='".$id_eresep."'";
		$ok2 = $this->dbhis->query($sql);

		$sql = "DELETE FROM soap_eresep WHERE id_eresep='".$id_eresep."'";
		$ok1 = $this->dbhis->query($sql);

		$oke = 'ok';

		echo $oke;
	}

	function remove_mst_tpl_racikan($id_tpl_racikan)
	{
		$oke = '';
		$sql = "SELECT * FROM soap_eresep_tpl_racikan a WHERE a.id_tpl_racikan='".$id_tpl_racikan."'";
		$query = $this->dbhis->query($sql);
		$jum_data = $query->num_rows();
		if($jum_data>0)
		{
			$sql = "DELETE FROM soap_eresep_tpl_racikan_det WHERE id_tpl_racikan='".$id_tpl_racikan."'";
			$ok1 = $this->dbhis->query($sql);

			$sql = "DELETE FROM soap_eresep_tpl_racikan WHERE id_tpl_racikan='".$id_tpl_racikan."'";
			$ok2 = $this->dbhis->query($sql);

			$oke = 'ok';
		}
		echo $oke;
	}

	public function list_riwayat_resep_online_v2($id_reg,$id_pasien)
	{
		/*
		$sql = "SELECT 	a.*,b.*
						FROM 		soap_eresep a, trx_reg b
						WHERE 	a.id_reg=b.id_reg AND b.id_pasien='".$id_pasien."'
						ORDER BY a.id_eresep DESC
						";
		*/
    //Query Asli PAk dadan
		// $sql = "SELECT 	c.`id_dokter`,d.`name` AS nama_dokter,a.*,b.*
		// 				FROM 		soap_eresep a, trx_reg b
		// 								,trx_reg_unit c, mst_dokter d
		// 				WHERE 	a.id_reg=b.id_reg AND b.id_pasien='".$id_pasien."'
		// 								AND a.id_reg=c.id_reg AND c.`id_dokter`=d.`id_dokter`
		// 				ORDER BY a.id_eresep DESC
		// 				";

    $sql = "SELECT ax.`id_dokter`,ax.nama_dokter, ax.*, ax.id_eresep, ax.eresepdate, ax.is_printed
            FROM (
              SELECT 	c.`id_dokter`,d.`name` AS nama_dokter,e.name as nama_dokter_ri
              				,b.*, a.id_eresep, a.eresepdate, a.is_printed
											,a.is_eresep_pulang
              FROM 		soap_eresep a
              				LEFT JOIN trx_reg_unit c ON (a.id_reg=c.id_reg)
                      LEFT JOIN mst_dokter d ON (c.`id_dokter`=d.`id_dokter`)
                      ,trx_reg b
                      LEFT JOIN mst_dokter e ON (b.`id_dokter_prt1`=e.`id_dokter`)
              WHERE 	a.id_reg=b.id_reg
              				AND b.id_pasien='".$id_pasien."'
              UNION ALL
              SELECT 	d.id_dokter, d.`name` AS nama_dokter, NULL AS nama_dokter_ri
              				,b.*, a.id_eresep, a.eresepdate, a.is_printed
											,a.is_eresep_pulang
              FROM 		soap_eresep a, trx_reg b, mst_dokter d
              WHERE 	b.ugd = 1 AND b.status<2
              				AND a.id_reg=b.id_reg
              				AND b.`id_dokter_jaga`=d.`id_dokter`
              				AND b.id_pasien='".$id_pasien."'
            ) ax
            ORDER BY ax.id_eresep DESC
            ";

		$query = $this->dbhis->query($sql);
		$rs_eresep = $query->result_array();
		foreach($rs_eresep as $k => $v)
		{
			if($v['rwjn']=='1')
				$tipe_rawat = 'R.Jalan';
			elseif($v['rwip']=='1')
				$tipe_rawat = 'R.Inap';
			else
				$tipe_rawat = 'UGD';

			$rs_eresep[$k]['tipe_rawat'] = $tipe_rawat;
			### ----------------------------------------
			/*
			if($v['is_printed']=='1')
			{
				#$rs_eresep[$k]['fungsi'] 							= 'Sudah diproses';
				$rs_eresep[$k]['fungsi'] = '<a href="#" onClick="javascript : if(confirm(\'Batal eresep via telp?\')) cancel_eresep_by_phone(\''.$v['id_eresep'].'\');return false;">[ Hapus ]</a>';
				$rs_eresep[$k]['bgcolor_riw_eresep'] 	= '#FFC09F';
			}
			else
			{
				$rs_eresep[$k]['fungsi'] = '<a href="#" onClick="javascript : if(confirm(\'hapus eresep ?\')) hapus_eresep_hangat(\''.$v['id_eresep'].'\');return false;">Hapus</a>';
				$rs_eresep[$k]['bgcolor_riw_eresep'] 	= 'white';
			}
			*/
			$checked = ($v['id_eresep']=='1') ? 'checked' : '';
			$rs_eresep[$k]['fungsi'] = '<input type="checkbox" class="cb_eresep_pulang" id="cb_eresep_pulang[]" name="cb_eresep_pulang[]" value="'.$v['id_eresep'].'" '.$checked.' onClick="javascript : set_resep_pulang(\''.$v['id_eresep'].'\',this.checked);">';
			$rs_eresep[$k]['bgcolor_riw_eresep'] = '#FFC09F';
		}

		$data = array(
			'rs_eresep'	=> $rs_eresep,
			'id_reg'		=> $id_reg
		);
		echo $this->load->view('list_riwayat_resep_online_pulang', $data, true);
	}



	public function setpembyaranobat($id_reg,$id_pasien){
		$id_eresep			 = $this->input->post('ideresepset');
		$subtotal_1			 = $this->input->post('det_subtotal',true);
		$datetime			 = date('Y-m-d H:i:s');
		$id_dokter_penginput = $this->session->userdata['sp']->id_dokter;
		//set increment nya
			$datanu       	= $this->Eresep_model->dnu();
			$setnourut		= $datanu->nourut;
			$urutan 		= (int) substr($setnourut, 4, 5);
			$setincrement 	= $urutan+1;
			$increset		= date('m').date('y').sprintf("%05s", $setincrement);
		//end set increment nya

		///////1
			$datafortrx_frm_resep	= $this->Eresep_model->m_trx_frm_resep($id_eresep);
			$regdateeresep 			= $datafortrx_frm_resep->eresepdate;
			$id_regeresep 			= $datafortrx_frm_resep->id_reg;
			$id_doktereresep 		= $datafortrx_frm_resep->id_dokter;
			$id_typeeresep			= "0";
			$id_kelaseresep			= "0";
		///////end 1

		### --- INSERT trx_frm_resep ---------------------------------
		$sql_insert_trx_frm_resep = "INSERT INTO `trx_frm_resep` (`id_resep`, `resepdate`, `id_reg`, `id_dokter`, `id_type`, `id_kelas`, `total`, `racikan`,`created`,`creator`) VALUES('".$increset."','".$regdateeresep."','".$id_regeresep."','".$id_doktereresep."','".$id_typeeresep."','".$id_kelaseresep."','".$subtotal_1."','0','".$datetime."','admin')";
		$this->dbhis->query($sql_insert_trx_frm_resep);
		
		### --- INSERT trx_frm_resep_det ---------------------------------
		$datafortrx_frm_resep_det	= $this->Eresep_model->m_trx_frm_resep_det($id_eresep);
		foreach($datafortrx_frm_resep_det as $k => $v){
	
		#### dibawah ini masukin header racikan di detail resep ---------
		$sql_insert_trx_frm_resep_det = "INSERT INTO `trx_frm_resep_det` (`id_resep`,`id_trx_det`,`name`,`satuan`,`qty`,`price`,`total`,`created`,`creator`) 
		VALUES('".$increset."','".$v['id_trx_det']."','".$v['name']."','".$v['satuan']."','".$v['qty']."','".$v['sale_price']."','".$v['total']."','".$datetime."','admin')";
		$this->dbhis->query($sql_insert_trx_frm_resep_det);
		}

		### --- INSERT trx_frm_resep_rck ---------------------------------
		$datafortrx_frm_resep_rck	= $this->Eresep_model->m_trx_frm_resep_rck($id_eresep);
		foreach($datafortrx_frm_resep_rck as $k2 => $v2){
	
		#### dibawah ini masukin header racikan di detail resep ---------
		$sql_insert_trx_frm_resep_det = "INSERT INTO `trx_frm_resep_rck` (`id_resep`,`id_reg`,`id_trx_from_soap`,`no_rck`,`id_rckt`,`subtotal`,`total`,`created`,`creator`) 
		VALUES('".$increset."','".$id_regeresep."','".$v2['id_eresep_det']."','".$v2['no_rck']."','".$v2['jenis_obat']."','".$v2['total']."','".$v2['total']."','".$datetime."','admin')";
		$this->dbhis->query($sql_insert_trx_frm_resep_det);
		}

		//$sql_insert_trx_reg_act = "INSERT INTO `trx_reg_act` (`id_reg`, `trxdate`, `id_reg_act`, `id_type`, `id_dokter`, `id_group_act`, `name`, `OBAT & ALKES`, `1`) VALUES('".$id_eresep."','".$id_fa[$k]."','".$obat[$k]."','".$jenis_obat[$k]."','".$qty[$k]."','".$dosis[$k]."','".$tme[$k]."','".$frekwensi[$k]."','".$note[$k]."')";
		//$this->dbhis->query($sql_insert_trx_reg_act);
		
		
		//exit;
		redirect('farmasi/');
	}

}
/* End of file Soap_eresep.php */
