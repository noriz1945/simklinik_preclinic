

<?php $this->theme->head('theme_default'); ?>
<title>Zia Aesthetic</title>

<?php $this->theme->wrapper_open('theme_default'); ?>
<?php require_once(APPPATH.'../assets/app_hn/dshomecafe/dshome-cmp-css.php');?>
<link rel="stylesheet" href="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/fontawesome/css/all.min.css'); ?>"> <!-- https://fontawesome.com/ -->
<link rel="stylesheet" href="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/css/tooplate-wave-cafe.css'); ?>">
<body>
  <div class="tm-container">
    <div class="tm-row">
      <!-- Site Header -->
      <div class="tm-left">
        <div class="tm-left-inner">
          <!--<div class="tm-site-header">
            <i class="fas fa-coffee fa-3x tm-site-logo"></i>
            <h1 class="tm-site-name">ZIA Cafe</h1>
          </div>-->
          <nav class="tm-site-nav">
            <ul class="tm-site-nav-ul">
            <li class="tm-page-nav-item">
                <a href="#contact" class="tm-page-link active">
                  <i class="fas fa-users tm-page-link-icon"></i>
                  <span>Input</span>
                </a>
              </li>
              <li class="tm-page-nav-item">
                <a href="#drink" class="tm-page-link">
                  <i class="fas fa-mug-hot tm-page-link-icon"></i>
                  <span>Minuman</span>
                </a>
              </li>
              <li class="tm-page-nav-item">
                <a href="#about" class="tm-page-link">
                  <i class="fas fa-pepper-hot tm-page-link-icon"></i>
                  <span>Makanan</span>
                </a>
              </li>
              <!--<li class="tm-page-nav-item">
                <a href="#special" class="tm-page-link">
                  <i class="fas fa-code tm-page-link-icon"></i>
                  <span>?</span>
                </a>
              </li>-->
            </ul>
          </nav>

          <!--rincian pemesanan-->
          <hr>
          <div class="row">
          <div class="col-xl-12 col-md-12">
          <div class="card table-card">
          <div class="card-header">
          <h5 class="datapembelikopi">-----//-----</h5>
          </div>
          <div class="card-block">
          <div class="table-responsive">
          <form method="POST" id="formsavepembelikopi">
          <table class="table table-hover m-b-0">
          <thead>
          <tr>
          <th>Produk</th>
          <th>&nbsp;</th>
          <th>Jumlah</th>
          <th>Harga</th>
          <th><i class="feather icon-trash-2 f-w-600 f-16 text-c-red"></i></th>
          </tr>
          </thead>
          <tbody class="setaddrow"></tbody>
          </table>
          </form>
          </div>
          </div>
          </div>
          </div>
          </div>
          <!--end rincian pemesanan-->
          
        </div>        
      </div>
      <div class="tm-right">
        <main class="tm-main">
          <!-- Contact Page -->
          <div id="contact" class="tm-page-content">
            <!--search pasien-->
            <div class="row">
            <div class="col-sm-12">
            <div class="card">
            <div class="card-header">
            <h5>Pencarian Pasien</h5>
            </div>
            <div class="card-block">
            <div class="row">
            <div class="col-sm-12 col-xl-4 m-b-30">
            <input type="text" class="form-control" id="search_nama_pasien" name="search_nama_pasien" placeholder="Nama Pasien">
            </div>
            <!--<div class="col-sm-12 col-xl-2 m-b-30">
            <input type="text" class="form-control" id="tgl_reg_st" name="tgl_reg_st" placeholder="Tanggal Registrasi 1">
            </div>
            <div class="col-sm-12 col-xl-2 m-b-30">
            <input type="text" class="form-control" id="tgl_reg_ed" name="tgl_reg_ed" placeholder="Tanggal Registrasi 2">
            </div>
            <div class="col-sm-12 col-xl-2 m-b-30">
            <select name="id_asuransi_set" id="id_asuransi_set" class="form-control form-control-info selmst_asuransi"></select>
            </div>
            <div class="col-sm-12 col-xl-2 m-b-30">
            <select name="id_dokter_set" id="id_dokter_set" class="form-control form-control-warning selmst_dokter"></select>
            </div>-->
            <div class="col-sm-12 col-xl-1 m-b-30">
            <button class="btn btn-success" id="cari_data"><i class="fa fa-search"></i> Cari</button>
            </div>
            <!--<div class="col-sm-12 col-xl-1 m-b-30">
            <button class="btn btn-warning" id="cari_data"><i class="fa fa-refresh"></i> Refresh</button>
            </div>-->
            </div>
            </div>
            <div class="card-block tab-icon">
            <div id="datalistrpo"></div>
            </div>
            </div>
            </div>
            </div>
            <!--end search pasien-->
          </div>
          <!-- end Contact Page -->

          <div id="drink" class="tm-page-content">
            <!-- Drink Menu Page -->
            <nav class="tm-black-bg tm-menu_tab_set-nav">
              <ul>
                <li>
                  <a href="#" class="tm-tab-link active" data-id="cold">Iced Coffee</a>
                </li>
                <li>
                  <a href="#" class="tm-tab-link" data-id="hot">Hot Coffee</a>
                </li>
                <li>
                  <a href="#" class="tm-tab-link" data-id="juice">Fruit Juice</a>
                </li>
              </ul>
            </nav>

            <div id="cold" class="tm-tab-content">
            <div class="tm-special-items">
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-01.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Special One</h2>
                  <p class="tm-special-item-text">Here is a short text description for the first special item. You are not allowed to redistribute this template ZIP file. attr-set-class="testcoba2"</p>
                  
                  <div class="input-group">
                  <span class="input-group-btn">
                    <button type="button" class="btn btn-danger btn-number"  data-type="minus" data-field="textcoba_quant[2]" attr-set-class="testcoba">
                      <span class="fa fa-minus"></span>
                    </button>
                  </span>
                    <input type="text" name="textcoba_quant[2]" class="form-control input-number testcoba" value="0" min="1" max="100">
                    <span class="input-group-btn">
                        <button type="button" class="btn btn-success btn-number" data-type="plus" data-field="textcoba_quant[2]" attr-set-class="testcoba">
                            <span class="fa fa-plus"></span>
                        </button>
                    </span>
                  </div>
                  <button class="btn btn-success addrowset testcoba" type="button" value="testcoba">ORDER</button>

                </div>
              </div>
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-02.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Second Item</h2>
                  <p class="tm-special-item-text">You are allowed to download, modify and use this template for your commercial or non-commercial websites.</p>  
                  <div class="input-group">
                  <span class="input-group-btn">
                    <button type="button" class="btn btn-danger btn-number"  data-type="minus" data-field="textcoba2_quant[2]" attr-set-class="testcoba2">
                      <span class="fa fa-minus"></span>
                    </button>
                  </span>
                    <input type="text" name="textcoba2_quant[2]" class="form-control input-number testcoba2" value="0" min="1" max="100">
                    <span class="input-group-btn">
                        <button type="button" class="btn btn-success btn-number" data-type="plus" data-field="textcoba2_quant[2]" attr-set-class="testcoba2">
                            <span class="fa fa-plus"></span>
                        </button>
                    </span>
                  </div>
                  <button class="btn btn-success addrowset testcoba2" type="button" value="testcoba2">ORDER</button>
                </div>
              </div>                 
            </div>  
            </div> 

            <div id="hot" class="tm-tab-content">
            <div class="tm-special-items">
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-03.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Third Special Item</h2>
                  <p class="tm-special-item-text">Pellentesque in ultrices mi, quis mollis nulla. Quisque sed commodo est, quis tincidunt nunc.</p>  
                  <button class="btn btn-success addrowset" type="button">plus</button>
                </div>
              </div>                   
            </div> 
            </div>

            <div id="juice" class="tm-tab-content">
            <div class="tm-special-items">
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-05.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Sixth Sense</h2>
                  <p class="tm-special-item-text">Here is a short text description for sixth item. This text is four lines.</p>  
                </div>
              </div>
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-06.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Seventh Item</h2>
                  <p class="tm-special-item-text">Curabitur eget erat sit amet sapien aliquet vulputate quis sed arcu.</p>  
                </div>
              </div>                      
            </div> 
            </div>

            <!-- end Drink Menu Page -->
          </div>

          <!-- Makanan -->
          <div id="about" class="tm-page-content">
            <!-- Drink Menu Page -->
            <nav class="tm-black-bg tm-menu_tab_set-nav">
              <ul>
                <li>
                  <a href="#" class="tm-tab-link" data-id="makanan_1">Seblak</a>
                </li>
                <li>
                  <a href="#" class="tm-tab-link" data-id="makanan_2">Nasi-Nasian</a>
                </li>
                <li>
                  <a href="#" class="tm-tab-link" data-id="makanan_3">Mie - miean</a>
                </li>
                <li>
                  <a href="#" class="tm-tab-link" data-id="makanan_4">Gorengan</a>
                </li>
              </ul>
            </nav>

            <div id="makanan_1" class="tm-tab-content">
            <div class="tm-special-items">
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-06.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Seventh Item</h2>
                  <p class="tm-special-item-text">Curabitur eget erat sit amet sapien aliquet vulputate quis sed arcu.</p>  
                </div>
              </div>                      
            </div>  
            </div> 

            <div id="makanan_2" class="tm-tab-content">
            <div class="tm-special-items">
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-02.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Second Item</h2>
                  <p class="tm-special-item-text">You are allowed to download, modify and use this template for your commercial or non-commercial websites.</p>  
                </div>
              </div>
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-03.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Third Special Item</h2>
                  <p class="tm-special-item-text">Pellentesque in ultrices mi, quis mollis nulla. Quisque sed commodo est, quis tincidunt nunc.</p>  
                </div>
              </div>                     
            </div> 
            </div>

            <div id="makanan_3" class="tm-tab-content">
            <div class="tm-special-items">
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-05.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Sixth Sense</h2>
                  <p class="tm-special-item-text">Here is a short text description for sixth item. This text is four lines.</p>  
                </div>
              </div>
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-06.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Seventh Item</h2>
                  <p class="tm-special-item-text">Curabitur eget erat sit amet sapien aliquet vulputate quis sed arcu.</p>  
                </div>
              </div>                      
            </div> 
            </div>

            <div id="makanan_4" class="tm-tab-content">
            <div class="tm-special-items">
              <div class="tm-black-bg tm-special-item">
                <img src="<?php echo base_url('assets/app_hn/dshomecafe/cafecss/img/special-06.jpg'); ?>" alt="Image">
                <div class="tm-special-item-description">
                  <h2 class="tm-text-primary tm-special-item-title">Seventh Item</h2>
                  <p class="tm-special-item-text">Curabitur eget erat sit amet sapien aliquet vulputate quis sed arcu.</p>  
                </div>
              </div>                      
            </div> 
            </div>
            <!-- end Drink Menu Page -->
          </div>
          <!-- end Makanan -->

          <!-- Special Items Page -->
          <div id="special" class="tm-page-content">
            <div class="tm-special-items">
                ???????????              
            </div>            
          </div>
          <!-- end Special Items Page -->

        </main>
      </div>    
    </div>
  </div>


</body>

<!--End section from wrapper_open-->
<?php $this->theme->wrapper_close('theme_default'); ?>
<?php $this->theme->script('theme_default'); ?>
<?php require_once(APPPATH.'../assets/app_hn/dshomecafe/dshome-cmp-js.php');?>
<script src=<?php echo base_url('assets/app_hn/dshomecafe/dshome.js'); ?>></script>