<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Eresep_model extends CI_Model
{

    public $table = 'soap_eresep';
		
    public $id = 'id_eresep';    
		public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }



//////////////////////////////////////
function mst_setting_harga(){
    $query=$this->db->query("SELECT tuslah,jasa_racik FROM mst_markup_harga");
    return $query->row(); 
  } 

  function detail_obatnya($id_obat){
    $query=$this->db->query("SELECT a.harga_margin
    FROM ish_mstrumus_det a 
    WHERE a.id_obat='$id_obat' AND a.id_comp='0001' AND a.status='0' GROUP BY a.id_comp ORDER BY a.no_rumus DESC");
    return $query->row(); 
  } 

  function detail_obat_eresep_nonracik($id_eresep){
    $query=$this->db->query("SELECT a.*,b.*
	FROM soap_eresep a, soap_eresep_det b
	WHERE a.id_eresep=b.id_eresep
	AND a.id_eresep='".$id_eresep."'
	AND b.is_racikan=0 AND b.status=0 AND b.is_validasi=0
	ORDER BY a.id_eresep DESC");
    return $query->result_array();
  }

  function list_detail_obat_eresep_nonracik($id_eresep){
    $query=$this->db->query("SELECT a.*,b.*
	FROM soap_eresep a, soap_eresep_det b
	WHERE a.id_eresep=b.id_eresep
	AND a.id_eresep='".$id_eresep."'
	AND b.is_racikan=0 AND b.status=0 AND b.is_validasi=1 
	ORDER BY a.id_eresep DESC");
    return $query->result_array();
  }
  function data_obat_search($id_eresep){
	$query=$this->db->query("SELECT * FROM soap_eresep_det WHERE id_eresep_det='$id_eresep'");
    return $query->row(); 
  }

  function data_obat_search_rck($id_eresep){
	$query=$this->db->query("SELECT * FROM soap_eresep_det_racikan WHERE id_eresep_det='$id_eresep'");
    return $query->result_array(); 
  }

  function delete_obatnya($id_eresep){
    $query=$this->db->query("UPDATE soap_eresep_det SET status=1 WHERE id_eresep_det='$id_eresep'");
  }

  function validasi_obatnya($id_eresep,$subtotal_new){
    $query=$this->db->query("UPDATE soap_eresep_det SET is_validasi=1, subtotal='$subtotal_new' WHERE id_eresep_det='$id_eresep'");
  }

  function cancel_obatnya($id_eresep,$subtotal_new){
    $query=$this->db->query("UPDATE soap_eresep_det SET is_validasi=0, subtotal='$subtotal_new' WHERE id_eresep_det='$id_eresep'");
  }

  function delete_obatnya_rck($id_eresep){
    $query=$this->db->query("UPDATE soap_eresep_det SET status=1 WHERE id_eresep_det='$id_eresep' AND is_racikan=1");
  }

  function hapus_obatnya_rck($id_eresep){
    $query=$this->db->query("UPDATE soap_eresep_det SET status=1 WHERE id_eresep_det='$id_eresep' AND is_racikan=1");
  }

  function validasi_obatnya_rck($id_eresep){
    $query=$this->db->query("UPDATE soap_eresep_det SET is_validasi=1 WHERE id_eresep_det='$id_eresep' AND is_racikan=1");
  }

  function cancel_obatnya_rck($id_eresep){
    $query=$this->db->query("UPDATE soap_eresep_det SET is_validasi=0 WHERE id_eresep_det='$id_eresep' AND is_racikan=1");
  }

  function edit_nonracikan($id_eresep,$qty,$harga_subtotal_set){
    $query=$this->db->query("UPDATE soap_eresep_det SET qty='$qty',subtotal=$harga_subtotal_set WHERE id_eresep_det='$id_eresep'");
  }

  function edit_racikan($id_eresep,$qty,$harga_subtotal_set){
    $query=$this->db->query("UPDATE soap_eresep_det_racikan SET qty='$qty',subtotal=$harga_subtotal_set WHERE id_eresep_det_racikan='$id_eresep'");
  }

  function validasi_obatnya_hrg_rck($id_item_racikan,$subtotal_new){
    $query=$this->db->query("UPDATE soap_eresep_det_racikan SET subtotal='$subtotal_new' WHERE id_eresep_det_racikan='$id_item_racikan'");
  }

  function cancel_obatnya_hrg_rck($id_item_racikan,$subtotal_new){
    $query=$this->db->query("UPDATE soap_eresep_det_racikan SET subtotal='$subtotal_new' WHERE id_eresep_det_racikan='$id_item_racikan'");
  }

  function data_search_obat($id_eresep){
    $query=$this->db->query("SELECT *
    FROM soap_eresep_det 
    WHERE id_eresep_det='$id_eresep'");
    return $query->row(); 
  } 

  function data_search_obat_racikan($id_eresep_det_racikan){
    $query=$this->db->query("SELECT *
    FROM soap_eresep_det_racikan 
    WHERE id_eresep_det_racikan='$id_eresep_det_racikan'");
    return $query->row(); 
  }

  function qty_obatnya_hrg_rck($id_eresep){
    $query=$this->db->query("SELECT qty FROM soap_eresep_det WHERE id_eresep_det='$id_eresep'");
    return $query->row(); 
  } 

  function sum_obatnya_hrg_rck($id_eresep){
    $query=$this->db->query("SELECT SUM(subtotal) AS grandtotal FROM soap_eresep_det_racikan WHERE id_eresep_det='$id_eresep'");
    return $query->row(); 
  } 

  function update_obatnya_hrg_rck($id_eresep,$grandtotal_sat_set,$cal_sub_racikan){
    $query=$this->db->query("UPDATE soap_eresep_det SET harga_satuan='$grandtotal_sat_set',subtotal='$cal_sub_racikan' WHERE id_eresep_det='$id_eresep'");
  }
  
//////////////////////////////////////

    // get all
    function get_all()
    {
        #$this->db->order_by($this->id, $this->order);
        #return $this->db->get($this->table)->result();
				
				$sql = "SELECT * FROM ".$this->table." ORDER BY ".$this->id." ".$this->order."";
				$query = $this->db->query($sql);
				$result = $query->result();
				return $result;
    }

    // get data by id
    function get_by_id($id)
    {
        #$this->db->where($this->id, $id);
        #return $this->db->get($this->table)->row();
				
				$sql = "SELECT 	* 
								FROM 		".$this->table." 
								WHERE		".$this->id."='".$id."'
								ORDER BY ".$this->id." ".$this->order."";
				$query = $this->db->query($sql);
				$result = $query->result();
				$result = $result[0];
				return $result;
    }
    
    // get total rows
    function total_rows($q = NULL) 
		{
			$sql = "SELECT 	* 
								FROM 		".$this->table."
								";
				if($q!=NULL)
				{
					$sql .= " WHERE FALSE ";
					$sql .= "OR LOWER(eresepdate) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(id_reg) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(id_dokter) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(id_type) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(id_kelas) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(total) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(id_ord) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(racikan) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(cancel) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(canceldate) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(created) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(creator) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(updated) LIKE LOWER('%".$q."%') ";
						$sql .= "OR LOWER(updater) LIKE LOWER('%".$q."%') ";
						}
				$sql = "SELECT COUNT(*) as total_rows FROM (".$sql.") abc";
				$query = $this->db->query($sql);
				$result = $query->result();
				$total_rows = $result[0]->total_rows;
				return $total_rows;
	}
	
    // get data with limit and search
    function get_limit_data($limit=NULL, $start = 0, $q = NULL) {
        #$this->db->order_by($this->id, $this->order);
        $sql = "SELECT 	* 
								FROM 		".$this->table."
								";
				if($q!=NULL)
				{
					$sql .= " WHERE FALSE ";
					$sql .= "OR LOWER(eresepdate) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(id_reg) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(id_dokter) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(id_type) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(id_kelas) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(total) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(id_ord) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(racikan) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(cancel) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(canceldate) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(created) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(creator) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(updated) LIKE LOWER('%".$q."%') ";
					$sql .= "OR LOWER(updater) LIKE LOWER('%".$q."%') ";
					}
				$sql .= " ORDER BY ".$this->id." ".$this->order." LIMIT ".$start.",".$limit."";
				$query = $this->db->query($sql);
				$result = $query->result();
				return $result;
	}
	
    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

    function get_data_soap($id_reg)
    {
        $sql = "SELECT  * 
                FROM    soap_cppt_trans                
                WHERE   id_reg = '".$id_reg."'
                ";
                        
        $query  = $this->dbsupp->query($sql);
        $rs     = $query->row_array();
        return $rs;
    }

	function dnu(){
	  $query=$this->db2->query("SELECT max(id_resep) as nourut FROM trx_frm_resep");
	  return $query->row();
	}

	function m_trx_frm_resep($id_eresep){
		$query=$this->db2->query("SELECT * FROM soap_eresep WHERE id_eresep='$id_eresep'");
		return $query->row();
	}

	function m_trx_frm_resep_det($id_eresep){
		$query=$this->dbhis->query("SELECT 
		a.id_trx_det,a.name, c.satuan,a.qty,b.sale_price, (b.sale_price * a.qty ) AS total
		FROM soap_eresep_det a
		LEFT JOIN mst_farmalkes b ON a.id_trx_det=b.id_fa
		LEFT JOIN mst_farmalkes_etk_amt c ON b.id_satuan=c.id_amt
		WHERE a.id_eresep='$id_eresep' AND a.is_racikan='0' 
		-- UNION ALL 
		-- SELECT
		-- a.id_trx_det,a.name, c.satuan,a.qty,b.sale_price, (b.sale_price * a.qty ) AS total
		-- FROM soap_eresep_det_racikan a
		-- LEFT JOIN mst_farmalkes b ON a.id_trx_det=b.id_fa
		-- LEFT JOIN mst_farmalkes_etk_amt c ON b.id_satuan=c.id_amt
		-- WHERE a.id_eresep='$id_eresep'
		");
		return $query->result_array();
	}

	function m_trx_frm_resep_rck($id_eresep){
		$query=$this->db2->query("SELECT ROW_NUMBER() OVER() AS no_rck,
		a.id_eresep_det,SUM((b.sale_price * d.qty)) AS total,d.jenis_obat
		FROM soap_eresep_det_racikan a
		LEFT JOIN mst_farmalkes b ON a.id_trx_det=b.id_fa
		LEFT JOIN mst_farmalkes_etk_amt c ON b.id_satuan=c.id_amt
		LEFT JOIN soap_eresep_det d ON (a.id_eresep_det=d.id_eresep_det AND d.is_racikan='1')
		WHERE a.id_eresep='$id_eresep' GROUP BY a.id_eresep_det ORDER BY a.id_eresep_det ASC");
		return $query->result_array();
	}


	

	


}

/* End of file Eresep_model.php */
/* Location: ./application/models/Eresep_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2019-01-18 05:09:16 */
/* http://harviacode.com */