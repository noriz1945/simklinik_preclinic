<?php
defined('BASEPATH') or exit('No direct script access allowed');

use Box\Spout\Reader\Common\Creator\ReaderEntityFactory;

class Cafe extends MX_Controller
{

    function __construct()
    {
        parent::__construct();
        //load model
        $this->load->helper('url');
        $this->load->helper('html');
		$this->load->module('auth');
		$this->auth->check_session();
		$this->load->model('MCafe', 'mdl');
    }

    public function index()
    {
        $username                       = @$this->session->userdata['sp']->username;
        $idrole                         = @$this->session->userdata['sp']->id_role;
        $datet                          = date('Y-m-d H:i:s');

        $datamv = array(
			'username'	=> $username,
            'idrole'    => $idrole
        );

        $this->load->view('vhome', $datamv);
    }

    public function data_poli_umum(){
        $data   = $this->mdl->getdatapoliumum7();
        $datasend = json_encode($data);
        echo $datasend;
    }

    public function data_poli_gigi(){
        $data   = $this->mdl->getdatapoligigi7();
        $datasend = json_encode($data);
        echo $datasend;
    }
    
    public function data_penjualan_obat(){
        $data   = $this->mdl->getdatapenjualanobat();
        $datasend = json_encode($data);
        echo $datasend;
    }


        ///////////////////////////////LIST PASIEN
        function listpasien(){
            $name       = @$this->session->userdata['sp']->name;
            $login_name = @$this->session->userdata['sp']->login_name;
            $nmpasien   = $this->input->post('nmpasien');
            $tgl_reg_1  = $this->input->post('stdate');
            $tgl_reg_2  = $this->input->post('endate');
            $asuransi   = $this->input->post('idasuransi');
            $dokter     = $this->input->post('iddokter');
    
            if($nmpasien ==''){
                $set_qry_nmpasien = NULL;
            }else{
                $set_qry_nmpasien = "AND b.name LIKE '%".$nmpasien."%'";
            }
    
            if($tgl_reg_1 =='' && $tgl_reg_2==''){
                $set_qry_tglreg = NULL;
            }else{
                $set_qry_tglreg = "AND DATE_FORMAT(a.regdate, '%d-%m-%Y') BETWEEN '$tgl_reg_1' AND '$tgl_reg_2'";
            }
    
            if($asuransi =='' || $asuransi ==0){
                $set_qry_asuransi = NULL;
            }else{
                $set_qry_asuransi = "AND a.id_asuransi='$asuransi'";
            }
    
            if($dokter =='' || $dokter ==0){
                $set_qry_dokter = NULL;
            }else{
                $set_qry_dokter = "AND a.id_dokter_prt1='$dokter'";
            }
    
            $data       = $this->mdl->mpasien($set_qry_nmpasien,$set_qry_tglreg,$set_qry_asuransi,$set_qry_dokter);
            $datasend = json_encode($data);
            echo $datasend;
        }
    
        function mstdokterset(){
            $data       = $this->mdl->mst_dokter();
            $datasend = json_encode($data);
            echo $datasend;
        }
        function mstasuransiset(){
            $data       = $this->mdl->mst_asuransi();
            $datasend = json_encode($data);
            echo $datasend;
        }
    
        ///////////////////////////////END LIST PASIEN
}
